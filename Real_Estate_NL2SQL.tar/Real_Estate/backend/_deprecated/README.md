# Quarantined dead code (safe to delete)

These modules were not imported by the production conversation graph
(`app/agents/free_chat/graph.py`) or any runtime code — only by each other
and by the tests moved here alongside them. They were superseded by:

- `deterministic_builder.build_sql`  (replaces query_builders + build_* nodes)
- `nodes/level3_query_planner.py`     (replaces build_deterministic_query)
- `nodes/level4_response.py`          (replaces summarize)
- `nodes/level1_extraction.py` + regex extractors (replace classify_intent)
- `nodes/needs_clarification.py`      (replaces clarify)

Kept in the live tree: `conversation/action_classifier.py` (its
`ConversationAction` enum is still used by `nodes/classify_action.py`; only
its `determine_action` function is now unused).

Verify the suite still passes, then delete this folder.
