"""Tests for deterministic COUNT and AGGREGATION SQL builders (Sprint 3).

COVERAGE
--------
Unit tests (no DB, no LLM required):
  TestBuildCountQuery         — build_count_query(...) output shape and filters
  TestBuildAggregationQuery   — build_aggregation_query(...) function detection
  TestCountQueryValidation    — generated SQL passes the existing SQL validator
  TestAggregationValidation   — generated SQL passes the existing SQL validator
  TestDeterministicQueryNode  — build_deterministic_query_node state machine
  TestSummarizeCount          — _summarize_count deterministic text output
  TestSummarizeAggregation    — _summarize_aggregation deterministic text output

Integration tests (full graph, mock LLM + mock DB):
  TestCountIntegration        — end-to-end graph runs for all 3 COUNT scenarios
  TestAggregationIntegration  — end-to-end graph runs for all 3 AGGREGATION scenarios
  TestNoCityLeakage           — previous-turn city does not bleed into new turn
  TestContextTransitionsPreserved — existing context-transition behaviour unchanged

SUCCESS CRITERIA
----------------
- Count returns a number only (no property cards, no SQL fragments).
- Aggregation returns a computed value only (no property cards).
- No wrong intent mapping (e.g. sell instead of buy).
- No accidental city leakage from previous turns.
- No generic "I wasn't able to complete that query" for COUNT / AGGREGATION.
- No SQL built using nonexistent longitude/latitude fields for these paths.
- All existing context-transition tests continue to pass (spot-checked here).
"""

from __future__ import annotations

import re
import pytest

# ---------------------------------------------------------------------------
# Unit: query builder functions
# ---------------------------------------------------------------------------
from app.agents.free_chat.query_builders import build_count_query, build_aggregation_query
from app.agents.free_chat.utils import validate_sql
from app.domain.chat.schemas import SearchContext


# ── build_count_query ──────────────────────────────────────────────────────

class TestBuildCountQuery:
    """Unit tests for build_count_query — no DB, no LLM."""

    def _ctx(self, **kwargs) -> SearchContext:
        return SearchContext(**kwargs)

    def test_count_apartments_for_rent_in_rome(self):
        ctx = self._ctx(city="Rome", intent="rent", property_type="apartment")
        sql = build_count_query(ctx)
        assert "SELECT COUNT(*) AS property_count" in sql
        assert "FROM properties" in sql
        assert "city = 'Rome'" in sql
        assert "intent = 'rent'" in sql
        assert "property_type = 'apartment'" in sql

    def test_count_under_300k_in_berlin(self):
        ctx = self._ctx(city="Berlin", max_price=300000)
        sql = build_count_query(ctx)
        assert "COUNT(*)" in sql
        assert "city = 'Berlin'" in sql
        assert "price <= 300000" in sql

    def test_count_two_bedroom_apartments_in_paris(self):
        ctx = self._ctx(city="Paris", property_type="apartment", bedrooms=2)
        sql = build_count_query(ctx)
        assert "COUNT(*)" in sql
        assert "city = 'Paris'" in sql
        assert "property_type = 'apartment'" in sql
        assert "bedrooms = 2" in sql

    def test_count_no_filters_returns_global_count(self):
        ctx = self._ctx()
        sql = build_count_query(ctx)
        assert "COUNT(*)" in sql
        assert "WHERE" not in sql

    def test_count_does_not_use_latitude_or_longitude(self):
        """COUNT queries must NEVER reference city_centers coordinates."""
        ctx = self._ctx(city="Rome", intent="rent")
        sql = build_count_query(ctx)
        assert "latitude" not in sql.lower()
        assert "longitude" not in sql.lower()
        assert "city_centers" not in sql.lower()

    def test_count_does_not_use_join(self):
        """COUNT queries should only touch the properties table."""
        ctx = self._ctx(city="Amsterdam")
        sql = build_count_query(ctx)
        assert "join" not in sql.lower()

    def test_count_intent_rent_not_sell(self):
        """intent='rent' must produce intent = 'rent', not 'sell'."""
        ctx = self._ctx(intent="rent")
        sql = build_count_query(ctx)
        assert "intent = 'rent'" in sql
        assert "sell" not in sql.lower()

    def test_count_intent_buy_not_sell(self):
        ctx = self._ctx(intent="buy")
        sql = build_count_query(ctx)
        assert "intent = 'buy'" in sql
        assert "sell" not in sql.lower()

    def test_count_with_bathrooms_filter(self):
        ctx = self._ctx(city="London", bathrooms=2)
        sql = build_count_query(ctx)
        assert "bathrooms = 2" in sql

    def test_count_single_quotes_escape(self):
        """City names with single quotes should not break the SQL."""
        # All supported cities are safe, but verify escaping path
        ctx = self._ctx(city="Paris")
        sql = build_count_query(ctx)
        # No unmatched single quote
        assert sql.count("'") % 2 == 0


# ── build_aggregation_query ────────────────────────────────────────────────

class TestBuildAggregationQuery:
    """Unit tests for build_aggregation_query — no DB, no LLM."""

    def _ctx(self, **kwargs) -> SearchContext:
        return SearchContext(**kwargs)

    def test_average_price_houses_in_rome(self):
        ctx = self._ctx(city="Rome", property_type="house")
        sql = build_aggregation_query(ctx, "What is the average price of houses in Rome?")
        assert "avg(price)" in sql.lower()
        assert "avg_price" in sql.lower()
        assert "city = 'Rome'" in sql
        assert "property_type = 'house'" in sql

    def test_cheapest_rent_in_paris(self):
        ctx = self._ctx(city="Paris", intent="rent")
        sql = build_aggregation_query(ctx, "What is the cheapest rent available in Paris?")
        assert "min(price)" in sql.lower()
        assert "min_price" in sql.lower()
        assert "city = 'Paris'" in sql
        assert "intent = 'rent'" in sql

    def test_highest_priced_apartment_in_berlin(self):
        ctx = self._ctx(city="Berlin", property_type="apartment")
        sql = build_aggregation_query(ctx, "What is the highest priced apartment in Berlin?")
        assert "max(price)" in sql.lower()
        assert "max_price" in sql.lower()
        assert "city = 'Berlin'" in sql
        assert "property_type = 'apartment'" in sql

    def test_default_to_avg_when_no_keyword(self):
        ctx = self._ctx(city="London")
        sql = build_aggregation_query(ctx, "What is the price in London?")
        assert "avg(price)" in sql.lower()

    def test_aggregation_does_not_use_latitude_longitude(self):
        ctx = self._ctx(city="Rome")
        sql = build_aggregation_query(ctx, "average price in Rome")
        assert "latitude" not in sql.lower()
        assert "longitude" not in sql.lower()
        assert "city_centers" not in sql.lower()

    def test_aggregation_does_not_apply_max_price_filter(self):
        """max_price from SearchContext must NOT be applied as a WHERE filter
        in aggregation queries — the user is asking for the aggregate value,
        not restricting the computation to their budget range."""
        ctx = self._ctx(city="Paris", max_price=500000)
        sql = build_aggregation_query(ctx, "average price in Paris")
        assert "price <=" not in sql
        assert "max_price" not in sql.lower() or "AS max_price" in sql.lower()

    def test_aggregation_intent_rent_not_sell(self):
        ctx = self._ctx(city="Paris", intent="rent")
        sql = build_aggregation_query(ctx, "cheapest rent in Paris")
        assert "intent = 'rent'" in sql
        assert "sell" not in sql.lower()

    def test_aggregation_no_filters_omits_where(self):
        ctx = self._ctx()
        sql = build_aggregation_query(ctx, "average price")
        assert "WHERE" not in sql

    def test_various_agg_keywords(self):
        ctx = self._ctx(city="Amsterdam")
        cases = [
            ("average", "AVG"),
            ("avg", "AVG"),
            ("mean price", "AVG"),
            ("lowest", "MIN"),
            ("minimum", "MIN"),
            ("cheapest", "MIN"),
            ("highest", "MAX"),
            ("maximum", "MAX"),
            ("most expensive", "MAX"),
        ]
        for keyword, expected_func in cases:
            sql = build_aggregation_query(ctx, f"What is the {keyword} in Amsterdam?")
            assert expected_func in sql.upper(), (
                f"Expected {expected_func} for keyword '{keyword}', got: {sql}"
            )


# ── SQL validator acceptance ───────────────────────────────────────────────

class TestCountQueryValidation:
    """All COUNT queries built by build_count_query must pass validate_sql."""

    def _assert_valid(self, sql: str):
        ok, err = validate_sql(sql)
        assert ok, f"SQL failed validation: {err}\nSQL: {sql}"

    def test_basic_count_passes_validation(self):
        ctx = SearchContext(city="Rome", intent="rent", property_type="apartment")
        self._assert_valid(build_count_query(ctx))

    def test_count_with_price_passes_validation(self):
        ctx = SearchContext(city="Berlin", max_price=300000)
        self._assert_valid(build_count_query(ctx))

    def test_count_with_bedrooms_passes_validation(self):
        ctx = SearchContext(city="Paris", property_type="apartment", bedrooms=2)
        self._assert_valid(build_count_query(ctx))

    def test_count_no_filters_passes_validation(self):
        ctx = SearchContext()
        self._assert_valid(build_count_query(ctx))

    def test_count_all_filters_passes_validation(self):
        ctx = SearchContext(
            city="London", intent="buy", property_type="house",
            bedrooms=3, bathrooms=2, max_price=800000,
        )
        self._assert_valid(build_count_query(ctx))


class TestAggregationValidation:
    """All AGGREGATION queries built by build_aggregation_query must pass validate_sql."""

    def _assert_valid(self, sql: str):
        ok, err = validate_sql(sql)
        assert ok, f"SQL failed validation: {err}\nSQL: {sql}"

    def test_avg_price_passes_validation(self):
        ctx = SearchContext(city="Rome", property_type="house")
        self._assert_valid(build_aggregation_query(ctx, "average price"))

    def test_min_price_passes_validation(self):
        ctx = SearchContext(city="Paris", intent="rent")
        self._assert_valid(build_aggregation_query(ctx, "cheapest rent"))

    def test_max_price_passes_validation(self):
        ctx = SearchContext(city="Berlin", property_type="apartment")
        self._assert_valid(build_aggregation_query(ctx, "highest priced apartment"))

    def test_aggregation_no_filters_passes_validation(self):
        ctx = SearchContext()
        self._assert_valid(build_aggregation_query(ctx, "average price"))


# ---------------------------------------------------------------------------
# Unit: deterministic query node
# ---------------------------------------------------------------------------
from app.agents.free_chat.nodes.build_deterministic_query import build_deterministic_query_node


class TestDeterministicQueryNode:
    """Unit tests for the build_deterministic_query_node state machine."""

    async def _invoke(self, state: dict) -> dict:
        """Helper — node accepts (state, config); config not needed here."""
        return await build_deterministic_query_node(state, config={})

    @pytest.mark.asyncio
    async def test_count_intent_produces_count_sql(self):
        state = {
            "intent": "count",
            "user_message": "How many apartments are for rent in Rome?",
            "search_context": {
                "city": "Rome",
                "intent": "rent",
                "property_type": "apartment",
            },
        }
        result = await self._invoke(state)
        assert result["sql_valid"] is True
        assert "COUNT(*)" in result["generated_sql"].upper()
        assert result["sql_error"] == ""

    @pytest.mark.asyncio
    async def test_aggregation_intent_produces_agg_sql(self):
        state = {
            "intent": "aggregation",
            "user_message": "What is the average price of houses in Rome?",
            "search_context": {
                "city": "Rome",
                "property_type": "house",
            },
        }
        result = await self._invoke(state)
        assert result["sql_valid"] is True
        assert "AVG" in result["generated_sql"].upper()
        assert result["sql_error"] == ""

    @pytest.mark.asyncio
    async def test_unsupported_intent_returns_error(self):
        state = {
            "intent": "filter_search",
            "user_message": "Show me flats in Paris",
            "search_context": {"city": "Paris"},
        }
        result = await self._invoke(state)
        assert result["sql_valid"] is False
        assert "unsupported intent" in result["sql_error"].lower()

    @pytest.mark.asyncio
    async def test_count_preserves_retry_count(self):
        state = {
            "intent": "count",
            "user_message": "How many properties?",
            "search_context": {},
            "retry_count": 1,
        }
        result = await self._invoke(state)
        assert result["retry_count"] == 1  # not incremented by deterministic node

    @pytest.mark.asyncio
    async def test_count_sql_does_not_reference_city_centers(self):
        state = {
            "intent": "count",
            "user_message": "How many houses can I buy in Berlin?",
            "search_context": {"city": "Berlin", "intent": "buy", "property_type": "house"},
        }
        result = await self._invoke(state)
        assert "city_centers" not in result["generated_sql"].lower()
        assert "latitude" not in result["generated_sql"].lower()
        assert "longitude" not in result["generated_sql"].lower()


# ---------------------------------------------------------------------------
# Unit: summarize node helpers
# ---------------------------------------------------------------------------
from app.agents.free_chat.nodes.summarize import _summarize_count, _summarize_aggregation


class TestSummarizeCount:
    """Unit tests for the _summarize_count deterministic formatter."""

    def test_nonzero_count_with_context(self):
        ctx = SearchContext(city="Rome", intent="rent", property_type="apartment")
        msg = _summarize_count([{"property_count": 42}], ctx)
        assert "42" in msg
        assert "apartment" in msg.lower()
        assert "rent" in msg.lower()
        assert "Rome" in msg

    def test_zero_count_returns_no_results_message(self):
        ctx = SearchContext(city="Berlin")
        msg = _summarize_count([{"property_count": 0}], ctx)
        assert "no" in msg.lower() or "0" in msg

    def test_count_one_is_singular(self):
        ctx = SearchContext(city="Paris")
        msg = _summarize_count([{"property_count": 1}], ctx)
        assert "1" in msg

    def test_empty_results_treated_as_zero(self):
        ctx = SearchContext(city="Amsterdam")
        msg = _summarize_count([], ctx)
        assert "no" in msg.lower() or "0" in msg

    def test_count_does_not_contain_sql_fragment(self):
        ctx = SearchContext(city="Rome", intent="rent")
        msg = _summarize_count([{"property_count": 7}], ctx)
        assert "SELECT" not in msg.upper()
        assert "FROM" not in msg.upper()
        assert "WHERE" not in msg.upper()

    def test_count_with_bedrooms_in_message(self):
        ctx = SearchContext(city="Paris", bedrooms=2, property_type="apartment")
        msg = _summarize_count([{"property_count": 15}], ctx)
        assert "15" in msg
        assert "2" in msg  # bedrooms mentioned

    def test_thousands_separator_for_large_count(self):
        ctx = SearchContext()
        msg = _summarize_count([{"property_count": 1234}], ctx)
        assert "1,234" in msg


class TestSummarizeAggregation:
    """Unit tests for the _summarize_aggregation deterministic formatter."""

    def test_avg_price_houses_rome(self):
        ctx = SearchContext(city="Rome", property_type="house")
        msg = _summarize_aggregation([{"avg_price": 450000}], ctx)
        assert "450,000" in msg or "450000" in msg
        assert "€" in msg  # Rome → EUR
        assert "average" in msg.lower()
        assert "house" in msg.lower()
        assert "Rome" in msg

    def test_min_price_rent_paris(self):
        ctx = SearchContext(city="Paris", intent="rent")
        msg = _summarize_aggregation([{"min_price": 1200}], ctx)
        assert "1,200" in msg or "1200" in msg
        assert "€" in msg
        assert "lowest" in msg.lower() or "cheapest" in msg.lower() or "minimum" in msg.lower()

    def test_max_price_apartment_berlin(self):
        ctx = SearchContext(city="Berlin", property_type="apartment")
        msg = _summarize_aggregation([{"max_price": 750000}], ctx)
        assert "750,000" in msg or "750000" in msg
        assert "highest" in msg.lower() or "maximum" in msg.lower()
        assert "Berlin" in msg

    def test_london_uses_gbp_symbol(self):
        ctx = SearchContext(city="London", property_type="house")
        msg = _summarize_aggregation([{"avg_price": 600000}], ctx)
        assert "£" in msg

    def test_empty_results_returns_no_results_message(self):
        ctx = SearchContext(city="Rome")
        msg = _summarize_aggregation([], ctx)
        assert "no" in msg.lower() or "not found" in msg.lower()

    def test_null_value_returns_no_results(self):
        ctx = SearchContext(city="Paris")
        msg = _summarize_aggregation([{"avg_price": None}], ctx)
        assert "no" in msg.lower()

    def test_aggregation_does_not_contain_sql_fragment(self):
        ctx = SearchContext(city="Rome")
        msg = _summarize_aggregation([{"avg_price": 300000}], ctx)
        assert "SELECT" not in msg.upper()
        assert "AVG" not in msg.upper()
        assert "FROM" not in msg.upper()


# ---------------------------------------------------------------------------
# Integration: full graph with mock LLM + mock DB
# ---------------------------------------------------------------------------
from app.agents.free_chat.graph import build_graph
from app.agents.free_chat.state import AgentState
from app.infrastructure.llm.base import LLMProvider
import json


class _MockResult:
    """Minimal stand-in for SQLAlchemy CursorResult.

    ``rows_to_dicts(rows, keys)`` in execute_query_node calls
    ``dict(zip(keys, row))`` for each row, so rows must be sequences
    (tuples), not pre-built dicts.
    """

    def __init__(self, rows, keys):
        # Convert dict rows to tuples ordered by keys so zip works correctly.
        self._keys = keys
        self._rows = [
            tuple(r[k] for k in keys) if isinstance(r, dict) else r
            for r in rows
        ]

    def keys(self):
        return self._keys

    def fetchmany(self, n=50):
        return self._rows


class _MockConnection:
    def __init__(self, rows, keys):
        self._rows = rows
        self._keys = keys

    async def execute(self, query):
        return _MockResult(self._rows, self._keys)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


class _MockDBEngine:
    """Mock DB engine.  Rows/keys can be swapped per test."""

    def __init__(self, rows=None, keys=None):
        self._rows = rows or []
        self._keys = keys or []

    def connect(self):
        return _MockConnection(self._rows, self._keys)


class _CountMockLLM(LLMProvider):
    """Deterministic mock LLM that always routes to COUNT intent."""

    def __init__(self, constraints: dict | None = None):
        self._constraints = constraints or {}

    async def invoke(self, messages: list, **kwargs) -> str:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return json.dumps({"action": "new_search"})
        if "query classifier" in system or "intent" in system:
            return json.dumps({"intent": "count"})
        if "parameter extractor" in system or "extractor" in system:
            return json.dumps(self._constraints)
        # summarise / clarify / other
        return "Here is the count result."

    async def invoke_json(self, messages: list, **kwargs) -> dict:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return {"action": "new_search"}
        if "query classifier" in system or "intent" in system:
            return {"intent": "count"}
        if "parameter extractor" in system or "extractor" in system:
            return self._constraints
        return {}


class _AggMockLLM(LLMProvider):
    """Deterministic mock LLM that always routes to AGGREGATION intent."""

    def __init__(self, constraints: dict | None = None):
        self._constraints = constraints or {}

    async def invoke(self, messages: list, **kwargs) -> str:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return json.dumps({"action": "new_search"})
        if "query classifier" in system or "intent" in system:
            return json.dumps({"intent": "aggregation"})
        if "parameter extractor" in system or "extractor" in system:
            return json.dumps(self._constraints)
        return "Here is the aggregation result."

    async def invoke_json(self, messages: list, **kwargs) -> dict:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return {"action": "new_search"}
        if "query classifier" in system or "intent" in system:
            return {"intent": "aggregation"}
        if "parameter extractor" in system or "extractor" in system:
            return self._constraints
        return {}


def _base_state(message: str, memory: dict | None = None) -> AgentState:
    return AgentState(
        session_id="test-session",
        user_message=message,
        memory=memory or {},
        retry_count=0,
    )


class TestCountIntegration:
    """End-to-end graph tests for COUNT intent (mock LLM + mock DB)."""

    @pytest.mark.asyncio
    async def test_apartments_for_rent_in_rome(self):
        graph = build_graph()
        llm = _CountMockLLM({"city": "Rome", "intent": "rent", "property_type": "apartment"})
        db = _MockDBEngine(rows=[{"property_count": 17}], keys=["property_count"])

        state = _base_state("How many apartments are for rent in Rome?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        # Must contain the count number
        assert "17" in msg, f"Expected '17' in message: {msg}"
        # Must NOT be the generic error message
        assert "wasn't able to complete" not in msg.lower(), f"Got generic error: {msg}"
        # Must NOT contain SQL fragments
        assert "SELECT" not in msg.upper(), f"SQL leaked into message: {msg}"
        # Must NOT return property cards
        assert result.get("properties", []) == [], f"Should have no property cards: {result.get('properties')}"

    @pytest.mark.asyncio
    async def test_properties_under_300k_in_berlin(self):
        graph = build_graph()
        llm = _CountMockLLM({"city": "Berlin", "max_price": 300000})
        db = _MockDBEngine(rows=[{"property_count": 43}], keys=["property_count"])

        state = _base_state("How many properties are under 300k in Berlin?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        assert "43" in msg, f"Expected '43' in message: {msg}"
        assert "wasn't able to complete" not in msg.lower()
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_two_bedroom_apartments_in_paris(self):
        graph = build_graph()
        llm = _CountMockLLM({"city": "Paris", "property_type": "apartment", "bedrooms": 2})
        db = _MockDBEngine(rows=[{"property_count": 8}], keys=["property_count"])

        state = _base_state("How many two-bedroom apartments are in Paris?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        assert "8" in msg, f"Expected '8' in message: {msg}"
        assert "wasn't able to complete" not in msg.lower()
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_count_sql_never_contains_lat_lon(self):
        """The SQL stored in generated_sql must never use lat/lon."""
        graph = build_graph()
        llm = _CountMockLLM({"city": "Rome", "intent": "rent"})
        db = _MockDBEngine(rows=[{"property_count": 5}], keys=["property_count"])

        state = _base_state("How many apartments are for rent in Rome?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        sql = result.get("generated_sql", "")
        assert "latitude" not in sql.lower(), f"latitude found in: {sql}"
        assert "longitude" not in sql.lower(), f"longitude found in: {sql}"

    @pytest.mark.asyncio
    async def test_count_intent_rent_not_sell(self):
        graph = build_graph()
        llm = _CountMockLLM({"city": "Paris", "intent": "rent"})
        db = _MockDBEngine(rows=[{"property_count": 22}], keys=["property_count"])

        state = _base_state("How many apartments are for rent in Paris?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        sql = result.get("generated_sql", "")
        assert "intent = 'rent'" in sql, f"Expected rent filter in: {sql}"
        assert "sell" not in sql.lower(), f"Wrong intent 'sell' in: {sql}"


class TestAggregationIntegration:
    """End-to-end graph tests for AGGREGATION intent (mock LLM + mock DB)."""

    @pytest.mark.asyncio
    async def test_average_price_of_houses_in_rome(self):
        graph = build_graph()
        llm = _AggMockLLM({"city": "Rome", "property_type": "house"})
        db = _MockDBEngine(rows=[{"avg_price": 420000}], keys=["avg_price"])

        state = _base_state("What is the average price of houses in Rome?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        assert "420" in msg, f"Expected price value in message: {msg}"
        assert "wasn't able to complete" not in msg.lower()
        assert "SELECT" not in msg.upper(), f"SQL fragment in message: {msg}"
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_cheapest_rent_in_paris(self):
        graph = build_graph()
        llm = _AggMockLLM({"city": "Paris", "intent": "rent"})
        db = _MockDBEngine(rows=[{"min_price": 850}], keys=["min_price"])

        state = _base_state("What is the cheapest rent available in Paris?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        assert "850" in msg, f"Expected price '850' in message: {msg}"
        assert "wasn't able to complete" not in msg.lower()
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_highest_priced_apartment_in_berlin(self):
        graph = build_graph()
        llm = _AggMockLLM({"city": "Berlin", "property_type": "apartment"})
        db = _MockDBEngine(rows=[{"max_price": 980000}], keys=["max_price"])

        state = _base_state("What is the highest priced apartment in Berlin?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        assert "980" in msg, f"Expected price '980' in message: {msg}"
        assert "wasn't able to complete" not in msg.lower()
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_aggregation_sql_never_contains_lat_lon(self):
        graph = build_graph()
        llm = _AggMockLLM({"city": "Berlin", "property_type": "apartment"})
        db = _MockDBEngine(rows=[{"max_price": 750000}], keys=["max_price"])

        state = _base_state("What is the highest priced apartment in Berlin?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        sql = result.get("generated_sql", "")
        assert "latitude" not in sql.lower()
        assert "longitude" not in sql.lower()
        assert "city_centers" not in sql.lower()

    @pytest.mark.asyncio
    async def test_aggregation_no_results_gives_clear_message(self):
        graph = build_graph()
        llm = _AggMockLLM({"city": "Rome"})
        # DB returns NULL aggregate (no matching rows)
        db = _MockDBEngine(rows=[{"avg_price": None}], keys=["avg_price"])

        state = _base_state("What is the average price in Rome?")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        msg = result.get("assistant_message", "")
        assert "no" in msg.lower() or "not found" in msg.lower(), (
            f"Expected no-results message, got: {msg}"
        )
        assert "wasn't able to complete" not in msg.lower()


# ---------------------------------------------------------------------------
# Integration: No city leakage across turns
# ---------------------------------------------------------------------------

class TestNoCityLeakage:
    """City set in a previous turn must not bleed into a fresh COUNT/AGGREGATION."""

    @pytest.mark.asyncio
    async def test_count_fresh_turn_does_not_use_previous_city(self):
        """A count query with city='Berlin' but memory from a Paris session
        must produce SQL with Berlin only — Paris must not appear."""
        graph = build_graph()
        # New turn with Berlin; memory carries Paris from a prior session
        paris_memory = {
            "search_context": {
                "city": "Paris",
                "intent": "rent",
                "property_type": "apartment",
            }
        }
        llm = _CountMockLLM({"city": "Berlin", "intent": "buy"})
        db = _MockDBEngine(rows=[{"property_count": 12}], keys=["property_count"])

        state = _base_state(
            "How many houses can I buy in Berlin?",
            memory=paris_memory,
        )
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        sql = result.get("generated_sql", "")
        assert "Berlin" in sql, f"Expected Berlin in SQL: {sql}"
        # Paris must not appear in SQL (city leakage)
        assert "Paris" not in sql, f"City leakage — Paris appeared in SQL: {sql}"

    @pytest.mark.asyncio
    async def test_aggregation_fresh_turn_does_not_use_previous_city(self):
        graph = build_graph()
        berlin_memory = {
            "search_context": {"city": "Berlin", "intent": "buy"}
        }
        llm = _AggMockLLM({"city": "Rome", "property_type": "house"})
        db = _MockDBEngine(rows=[{"avg_price": 390000}], keys=["avg_price"])

        state = _base_state(
            "What is the average price of houses in Rome?",
            memory=berlin_memory,
        )
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        sql = result.get("generated_sql", "")
        assert "Rome" in sql, f"Expected Rome in SQL: {sql}"
        assert "Berlin" not in sql, f"City leakage — Berlin appeared in SQL: {sql}"


# ---------------------------------------------------------------------------
# Regression: existing context-transition behaviour preserved
# ---------------------------------------------------------------------------
# Spot-check: filter_search still goes through generate_sql (LLM path),
# NOT through build_deterministic_query.

class _FilterSearchMockLLM(LLMProvider):
    """Mock LLM for filter_search intent — verifies LLM path is unchanged."""

    def __init__(self, constraints: dict | None = None):
        self._constraints = constraints or {}

    async def invoke(self, messages: list, **kwargs) -> str:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return json.dumps({"action": "new_search"})
        if "query classifier" in system or "intent" in system:
            return json.dumps({"intent": "filter_search"})
        if "parameter extractor" in system or "extractor" in system:
            return json.dumps(self._constraints)
        if "postgresql expert" in system:
            return "SELECT id, title, city, price FROM properties WHERE city = 'London' LIMIT 10"
        return "Found some properties for you."

    async def invoke_json(self, messages: list, **kwargs) -> dict:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return {"action": "new_search"}
        if "query classifier" in system or "intent" in system:
            return {"intent": "filter_search"}
        if "parameter extractor" in system or "extractor" in system:
            return self._constraints
        return {}


class _FilterMockDBEngine:
    """Mock DB returning property-like rows for filter_search tests."""

    def connect(self):
        return _FilterMockConnection()


class _FilterMockConnection:
    async def execute(self, query):
        return _FilterMockResult()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


class _FilterMockResult:
    def keys(self):
        return ["id", "title", "city", "price"]

    def fetchmany(self, n=50):
        return [{"id": 1, "title": "Nice flat", "city": "London", "price": 2000}]


class TestContextTransitionsPreserved:
    """Verify filter_search still uses the LLM/generate_sql path (not deterministic)."""

    @pytest.mark.asyncio
    async def test_filter_search_still_uses_llm_path(self):
        graph = build_graph()
        llm = _FilterSearchMockLLM({"city": "London", "intent": "rent"})
        db = _FilterMockDBEngine()

        state = _base_state("Show me apartments to rent in London")
        result = await graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})

        # filter_search should produce property cards (not a count/agg)
        # and go through the LLM-generated SQL path
        sql = result.get("generated_sql", "")
        assert "COUNT" not in sql.upper(), f"filter_search used COUNT path unexpectedly: {sql}"
        assert "AVG" not in sql.upper(), f"filter_search used AVG path unexpectedly: {sql}"
        # Should succeed and have a message
        assert result.get("assistant_message"), "Expected a summary message"
