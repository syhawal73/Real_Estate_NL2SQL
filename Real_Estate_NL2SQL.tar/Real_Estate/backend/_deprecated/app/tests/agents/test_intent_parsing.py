"""Unit tests for intent JSON parsing and QueryIntent enum validation (Phase 4.1).

These tests do not require a database or running LLM.
"""

import pytest

from app.agents.free_chat.nodes.classify_intent import _parse_intent_from_text
from app.domain.chat.schemas import QueryIntent


class TestParseIntentFromText:
    """Test intent parsing from various LLM output formats."""

    def test_valid_json_output(self):
        assert _parse_intent_from_text('{"intent": "filter_search"}') == "filter_search"

    def test_valid_json_with_whitespace(self):
        assert _parse_intent_from_text('  {"intent": "count"}  ') == "count"

    def test_valid_json_all_intents(self):
        """Every valid intent should be parseable from JSON."""
        for intent in QueryIntent:
            result = _parse_intent_from_text(f'{{"intent": "{intent.value}"}}')
            assert result == intent.value, f"Failed to parse intent: {intent.value}"

    def test_json_embedded_in_text(self):
        text = 'The intent is {"intent": "comparison"} based on the query.'
        assert _parse_intent_from_text(text) == "comparison"

    def test_plain_label_filter_search(self):
        assert _parse_intent_from_text("filter_search") == "filter_search"

    def test_plain_label_with_period(self):
        assert _parse_intent_from_text("count.") == "count"

    def test_plain_label_with_whitespace(self):
        assert _parse_intent_from_text("  ranking  ") == "ranking"

    def test_label_within_sentence(self):
        assert _parse_intent_from_text("I think this is a filter_search query") == "filter_search"

    def test_invalid_intent_returns_clarification(self):
        assert _parse_intent_from_text("i_dont_know") == "clarification_needed"

    def test_empty_string_returns_clarification(self):
        assert _parse_intent_from_text("") == "clarification_needed"

    def test_garbage_returns_clarification(self):
        assert _parse_intent_from_text("asdfghjkl 12345") == "clarification_needed"

    def test_invalid_json_structure(self):
        # When the JSON has a wrong key but the value doesn't match any intent,
        # it should fall back to clarification_needed
        assert _parse_intent_from_text('{"wrong_key": "some_random_value"}') == "clarification_needed"

    def test_json_with_extra_fields(self):
        text = '{"intent": "aggregation", "confidence": 0.9}'
        assert _parse_intent_from_text(text) == "aggregation"

    def test_markdown_fenced_json(self):
        text = '```json\n{"intent": "distinct"}\n```'
        # Should find the intent even in a fenced block
        assert _parse_intent_from_text(text) == "distinct"

    def test_pattern_search_intent(self):
        assert _parse_intent_from_text('{"intent": "pattern_search"}') == "pattern_search"

    def test_unsupported_intent(self):
        assert _parse_intent_from_text('{"intent": "unsupported"}') == "unsupported"

    def test_clarification_needed_intent(self):
        assert _parse_intent_from_text('{"intent": "clarification_needed"}') == "clarification_needed"

    def test_lookup_intent(self):
        assert _parse_intent_from_text("lookup") == "lookup"

    def test_listing_intent(self):
        assert _parse_intent_from_text("listing") == "listing"

    def test_radius_search_intent(self):
        assert _parse_intent_from_text("radius_search") == "radius_search"
