"""Tests for the deterministic RANKING query path (Sprint 3.3).

COVERAGE
--------
Unit tests (no DB, no LLM):
  TestParseRankingRequest     — dimension/order/limit/filter extraction
  TestBuildRankingQuery       — correct SQL structure, ORDER BY, LIMIT, no lat/lon
  TestRankingValidation       — built SQL passes the shared SQL validator
  TestFormatRankingMessage    — deterministic, SQL-free summary messages

Integration tests (full graph, mock LLM + mock DB):
  TestRankingIntegration      — the seven required end-to-end scenarios
  TestRankingRoutingGuards    — ranking never uses the free-form SQL path
  TestNoRankingContextLeakage — stale filters never bleed into a ranking query

REQUIRED CASES (from the ticket)
--------------------------------
  1. Show the 5 cheapest apartments in Berlin
  2. What are the 3 largest houses for sale in Paris?
  3. Show me the closest properties to the city centre in Rome
  4. Show the 5 closest houses in Amsterdam within 10km
  5. Ranking after unrelated search does not leak stale filters
  6. Ranking with explicit city switch honours the latest city only
  7. Ranking with explicit intent switch honours the latest intent only

SUCCESS CRITERIA
----------------
- Deterministic ranking results (same input → same output).
- Stable ORDER BY + LIMIT.
- No stale context leakage from prior turns.
- No generic "unable to complete" for supported cases.
- No fallback to free-form SQL generation for ranking queries.
"""

from __future__ import annotations

import json

import pytest

from app.agents.free_chat.query_builders import (
    RANK_DISTANCE,
    RANK_PRICE,
    RANK_SIZE,
    RankingRequest,
    build_ranking_query,
    format_ranking_message,
    parse_ranking_request,
)
from app.agents.free_chat.utils import validate_sql


# ===========================================================================
# Unit: parse_ranking_request
# ===========================================================================

class TestParseRankingRequest:
    """Dimension, order, limit and filter extraction from the user message."""

    def test_5_cheapest_apartments_in_berlin(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        assert r.ok is True
        assert r.rank_by == RANK_PRICE
        assert r.rank_order == "asc"
        assert r.limit == 5
        assert r.city == "Berlin"
        assert r.property_type == "apartment"

    def test_3_largest_houses_for_sale_in_paris(self):
        r = parse_ranking_request("What are the 3 largest houses for sale in Paris?")
        assert r.ok is True
        assert r.rank_by == RANK_SIZE
        assert r.rank_order == "desc"
        assert r.limit == 3
        assert r.city == "Paris"
        assert r.property_type == "house"
        assert r.intent == "buy"    # "for sale" → buy

    def test_closest_properties_to_city_centre_in_rome(self):
        r = parse_ranking_request("Show me the closest properties to the city centre in Rome")
        assert r.ok is True
        assert r.rank_by == RANK_DISTANCE
        assert r.rank_order == "asc"
        assert r.city == "Rome"

    def test_5_closest_houses_in_amsterdam_within_10km(self):
        r = parse_ranking_request("Show the 5 closest houses in Amsterdam within 10km")
        assert r.ok is True
        assert r.rank_by == RANK_DISTANCE
        assert r.rank_order == "asc"
        assert r.limit == 5
        assert r.city == "Amsterdam"
        assert r.property_type == "house"
        assert r.radius_km == 10.0

    def test_most_expensive_apartments(self):
        r = parse_ranking_request("Show the most expensive apartments in London")
        assert r.ok is True
        assert r.rank_by == RANK_PRICE
        assert r.rank_order == "desc"
        assert r.city == "London"
        assert r.property_type == "apartment"

    def test_smallest_apartments_in_amsterdam(self):
        r = parse_ranking_request("Show the smallest apartments in Amsterdam")
        assert r.ok is True
        assert r.rank_by == RANK_SIZE
        assert r.rank_order == "asc"
        assert r.city == "Amsterdam"
        assert r.property_type == "apartment"

    def test_default_limit_is_5(self):
        r = parse_ranking_request("Show the cheapest apartments in Berlin")
        assert r.ok is True
        assert r.limit == 5

    def test_explicit_top_10(self):
        r = parse_ranking_request("Show the top 10 cheapest apartments in Berlin")
        assert r.ok is True
        assert r.limit == 10

    def test_for_sale_maps_to_buy(self):
        r = parse_ranking_request("Show the 3 cheapest houses for sale in Rome")
        assert r.intent == "buy"

    def test_rental_detected(self):
        r = parse_ranking_request("Show the cheapest rental apartments in Paris")
        assert r.intent == "rent"

    def test_no_city_is_ok(self):
        """Ranking without a city is valid — queries all cities."""
        r = parse_ranking_request("Show the cheapest apartments")
        assert r.ok is True
        assert r.city is None

    def test_empty_message_returns_error(self):
        r = parse_ranking_request("")
        assert r.ok is False
        assert r.error

    def test_does_not_read_prior_context(self):
        """parse_ranking_request takes only the message — no context arg."""
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        assert r.city == "Berlin"
        # No invented city from prior context
        assert r.city != "Amsterdam"
        assert r.city != "London"

    def test_deterministic_repeatable(self):
        msg = "Show the 5 cheapest apartments in Berlin"
        r1 = parse_ranking_request(msg)
        r2 = parse_ranking_request(msg)
        assert (r1.rank_by, r1.rank_order, r1.limit, r1.city, r1.property_type) == \
               (r2.rank_by, r2.rank_order, r2.limit, r2.city, r2.property_type)

    def test_bedrooms_extraction(self):
        r = parse_ranking_request("Show the 5 cheapest 3-bedroom apartments in Berlin")
        assert r.bedrooms == 3

    def test_budget_extraction(self):
        r = parse_ranking_request("Show the largest houses under 500k in London")
        assert r.max_price == 500000


# ===========================================================================
# Unit: build_ranking_query
# ===========================================================================

class TestBuildRankingQuery:
    """Correct SQL structure — ORDER BY, LIMIT, no lat/lon joins."""

    def test_cheapest_apartments_in_berlin(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        sql = build_ranking_query(r)
        assert "ORDER BY price ASC" in sql
        assert "LIMIT 5" in sql
        assert "city = 'Berlin'" in sql
        assert "property_type = 'apartment'" in sql
        assert "FROM properties" in sql

    def test_3_largest_houses_for_sale_in_paris(self):
        r = parse_ranking_request("What are the 3 largest houses for sale in Paris?")
        sql = build_ranking_query(r)
        assert "ORDER BY size_sqm DESC" in sql
        assert "LIMIT 3" in sql
        assert "city = 'Paris'" in sql
        assert "property_type = 'house'" in sql
        assert "intent = 'buy'" in sql

    def test_closest_in_rome(self):
        r = parse_ranking_request("Show me the closest properties to the city centre in Rome")
        sql = build_ranking_query(r)
        assert "ORDER BY distance_from_city_km ASC" in sql
        assert "city = 'Rome'" in sql

    def test_closest_with_radius(self):
        r = parse_ranking_request("Show the 5 closest houses in Amsterdam within 10km")
        sql = build_ranking_query(r)
        assert "ORDER BY distance_from_city_km ASC" in sql
        assert "LIMIT 5" in sql
        assert "distance_from_city_km <= 10" in sql
        assert "city = 'Amsterdam'" in sql
        assert "property_type = 'house'" in sql

    def test_returns_property_card_columns(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        sql = build_ranking_query(r)
        for col in ("id", "title", "city", "neighbourhood", "intent", "price",
                     "bedrooms", "bathrooms", "size_sqm", "property_type",
                     "distance_from_city_km"):
            assert col in sql, f"Missing column: {col}"

    def test_no_latitude_longitude_or_city_centers(self):
        for msg in [
            "Show the 5 cheapest apartments in Berlin",
            "Show me the closest properties in Rome",
            "Show the 5 closest houses in Amsterdam within 10km",
        ]:
            sql = build_ranking_query(parse_ranking_request(msg))
            assert "latitude" not in sql.lower()
            assert "longitude" not in sql.lower()
            assert "city_centers" not in sql.lower()
            assert "join" not in sql.lower()

    def test_intent_never_becomes_sell(self):
        r = parse_ranking_request("What are the 3 largest houses for sale in Paris?")
        sql = build_ranking_query(r)
        assert "sell" not in sql.lower()
        assert "intent = 'buy'" in sql

    def test_build_on_invalid_request_raises(self):
        r = parse_ranking_request("")
        assert r.ok is False
        with pytest.raises(ValueError):
            build_ranking_query(r)

    def test_no_city_produces_no_city_filter(self):
        r = parse_ranking_request("Show the cheapest apartments")
        sql = build_ranking_query(r)
        assert "city =" not in sql


# ===========================================================================
# Unit: ranking SQLs pass the shared validator
# ===========================================================================

class TestRankingValidation:
    """Every ranking SQL must pass validate_sql (same gate as other paths)."""

    def _assert_valid(self, message: str):
        sql = build_ranking_query(parse_ranking_request(message))
        ok, err = validate_sql(sql)
        assert ok, f"SQL failed validation: {err}\nSQL: {sql}"

    def test_cheapest_apartments_valid(self):
        self._assert_valid("Show the 5 cheapest apartments in Berlin")

    def test_largest_houses_valid(self):
        self._assert_valid("What are the 3 largest houses for sale in Paris?")

    def test_closest_properties_valid(self):
        self._assert_valid("Show me the closest properties to the city centre in Rome")

    def test_closest_with_radius_valid(self):
        self._assert_valid("Show the 5 closest houses in Amsterdam within 10km")

    def test_most_expensive_valid(self):
        self._assert_valid("Show the most expensive apartments in London")

    def test_smallest_valid(self):
        self._assert_valid("Show the smallest apartments in Amsterdam")

    def test_with_bedrooms_valid(self):
        self._assert_valid("Show the 5 cheapest 3-bedroom apartments in Berlin")

    def test_with_budget_valid(self):
        self._assert_valid("Show the largest houses under 500k in London")


# ===========================================================================
# Unit: format_ranking_message
# ===========================================================================

class TestFormatRankingMessage:
    """Summary messages are deterministic, SQL-free, and describe the ranking."""

    def test_with_results(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        results = [{"id": i} for i in range(5)]
        msg = format_ranking_message(r, results)
        assert "cheapest" in msg.lower()
        assert "Berlin" in msg
        assert "apartment" in msg.lower()
        assert "5" in msg

    def test_zero_results(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        msg = format_ranking_message(r, [])
        assert "couldn't find" in msg.lower()
        assert "Berlin" in msg

    def test_fewer_results_than_limit(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        results = [{"id": i} for i in range(3)]
        msg = format_ranking_message(r, results)
        assert "3" in msg
        assert "only" in msg.lower()

    def test_message_never_contains_sql(self):
        r = parse_ranking_request("Show the 5 cheapest apartments in Berlin")
        results = [{"id": i} for i in range(5)]
        msg = format_ranking_message(r, results)
        assert "SELECT" not in msg.upper()
        assert "FROM" not in msg.upper()
        assert "WHERE" not in msg.upper()
        assert "ORDER BY" not in msg.upper()

    def test_closest_message(self):
        r = parse_ranking_request("Show me the closest properties in Rome")
        results = [{"id": i} for i in range(5)]
        msg = format_ranking_message(r, results)
        assert "closest" in msg.lower()
        assert "Rome" in msg

    def test_largest_message(self):
        r = parse_ranking_request("What are the 3 largest houses for sale in Paris?")
        results = [{"id": i} for i in range(3)]
        msg = format_ranking_message(r, results)
        assert "largest" in msg.lower()
        assert "Paris" in msg

    def test_radius_scope_in_message(self):
        r = parse_ranking_request("Show the 5 closest houses in Amsterdam within 10km")
        results = [{"id": i} for i in range(5)]
        msg = format_ranking_message(r, results)
        assert "10" in msg
        assert "km" in msg.lower()


# ===========================================================================
# Integration: full graph with mock LLM + mock DB
# ===========================================================================
from app.agents.free_chat.graph import build_graph
from app.agents.free_chat.state import AgentState
from app.infrastructure.llm.base import LLMProvider


class _RankingMockLLM(LLMProvider):
    """Mock LLM that always classifies the turn as RANKING.

    The ranking path does NOT call the LLM for SQL or summary — it is
    fully deterministic — so only the classify_intent / classify_action /
    extract_constraints calls matter here.
    """

    async def invoke(self, messages: list, **kwargs) -> str:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return json.dumps({"action": "new_search"})
        if "query classifier" in system or "intent" in system:
            return json.dumps({"intent": "ranking"})
        if "parameter extractor" in system or "extractor" in system:
            return json.dumps({})
        # Sentinel — should never appear in deterministic ranking output.
        return "LLM_FALLBACK_SHOULD_NOT_APPEAR"

    async def invoke_json(self, messages: list, **kwargs) -> dict:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return {"action": "new_search"}
        if "query classifier" in system or "intent" in system:
            return {"intent": "ranking"}
        if "parameter extractor" in system or "extractor" in system:
            return {}
        return {}


# ── Mock DB that returns rows based on city / ORDER BY / LIMIT ──────────

class _RankingMockResult:
    """SQLAlchemy CursorResult stand-in returning pre-configured rows."""

    def __init__(self, columns: list[str], rows: list[tuple]):
        self._columns = columns
        self._rows = rows

    def keys(self):
        return self._columns

    def fetchmany(self, n=50):
        return self._rows[:n]


# Standard property columns returned by ranking queries.
_PROP_COLS = [
    "id", "title", "city", "neighbourhood", "intent", "price",
    "bedrooms", "bathrooms", "size_sqm", "property_type", "distance_from_city_km",
]


def _make_prop_row(
    id: int, city: str, price: int, size_sqm: int, distance: float,
    intent: str = "buy", ptype: str = "apartment",
) -> tuple:
    """Build a property row tuple matching _PROP_COLS order."""
    return (
        id, f"Property {id}", city, "Centre", intent, price,
        2, 1, size_sqm, ptype, distance,
    )


# Pre-built rows for each city, already sorted by different dimensions.
_CITY_ROWS = {
    "Berlin": [
        _make_prop_row(1, "Berlin", 100000, 50, 3.0),
        _make_prop_row(2, "Berlin", 150000, 60, 5.0),
        _make_prop_row(3, "Berlin", 200000, 70, 7.0),
        _make_prop_row(4, "Berlin", 250000, 80, 9.0),
        _make_prop_row(5, "Berlin", 300000, 90, 11.0),
    ],
    "Paris": [
        _make_prop_row(10, "Paris", 200000, 100, 2.0, ptype="house"),
        _make_prop_row(11, "Paris", 300000, 120, 4.0, ptype="house"),
        _make_prop_row(12, "Paris", 400000, 150, 6.0, ptype="house"),
    ],
    "Rome": [
        _make_prop_row(20, "Rome", 180000, 55, 1.5),
        _make_prop_row(21, "Rome", 220000, 65, 3.0),
        _make_prop_row(22, "Rome", 260000, 75, 4.5),
        _make_prop_row(23, "Rome", 300000, 85, 6.0),
        _make_prop_row(24, "Rome", 340000, 95, 7.5),
    ],
    "Amsterdam": [
        _make_prop_row(30, "Amsterdam", 150000, 45, 2.0, ptype="house"),
        _make_prop_row(31, "Amsterdam", 200000, 55, 5.0, ptype="house"),
        _make_prop_row(32, "Amsterdam", 250000, 65, 8.0, ptype="house"),
        _make_prop_row(33, "Amsterdam", 300000, 75, 12.0, ptype="house"),
        _make_prop_row(34, "Amsterdam", 350000, 85, 15.0, ptype="house"),
    ],
    "London": [
        _make_prop_row(40, "London", 500000, 80, 3.0),
        _make_prop_row(41, "London", 600000, 90, 5.0),
        _make_prop_row(42, "London", 700000, 100, 7.0),
    ],
}


class _RankingMockConnection:
    """Connection that inspects SQL to pick the right city's rows and applies
    ORDER BY / LIMIT semantics at the mock level."""

    def __init__(self, city_rows: dict):
        self._city_rows = city_rows

    async def execute(self, query):
        sql = str(query).lower()
        # Find which city is in the WHERE clause
        rows = []
        for city, city_rows in self._city_rows.items():
            if f"city = '{city.lower()}'" in sql.lower() or f"city = '{city}'" in str(query):
                rows = list(city_rows)
                break
        else:
            # No city filter — return all rows
            rows = []
            for city_rows in self._city_rows.values():
                rows.extend(city_rows)

        # Apply property_type filter if present
        for ptype in ("apartment", "house"):
            if f"property_type = '{ptype}'" in str(query):
                rows = [r for r in rows if r[9] == ptype]  # index 9 = property_type
                break

        # Apply intent filter if present
        for intent_val in ("buy", "rent"):
            if f"intent = '{intent_val}'" in str(query):
                rows = [r for r in rows if r[4] == intent_val]  # index 4 = intent
                break

        # Apply radius filter if present
        import re
        radius_match = re.search(r"distance_from_city_km\s*<=\s*(\d+(?:\.\d+)?)", sql)
        if radius_match:
            max_dist = float(radius_match.group(1))
            rows = [r for r in rows if r[10] <= max_dist]  # index 10 = distance

        # Apply ORDER BY
        if "order by price asc" in sql:
            rows.sort(key=lambda r: r[5])       # index 5 = price
        elif "order by price desc" in sql:
            rows.sort(key=lambda r: r[5], reverse=True)
        elif "order by size_sqm desc" in sql:
            rows.sort(key=lambda r: r[8], reverse=True)  # index 8 = size_sqm
        elif "order by size_sqm asc" in sql:
            rows.sort(key=lambda r: r[8])
        elif "order by distance_from_city_km asc" in sql:
            rows.sort(key=lambda r: r[10])      # index 10 = distance
        elif "order by distance_from_city_km desc" in sql:
            rows.sort(key=lambda r: r[10], reverse=True)

        # Apply LIMIT
        limit_match = re.search(r"limit\s+(\d+)", sql)
        if limit_match:
            limit = int(limit_match.group(1))
            rows = rows[:limit]

        return _RankingMockResult(_PROP_COLS, rows)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


class _RankingMockDBEngine:
    """Mock engine that returns city-specific ranked property rows."""

    def __init__(self, city_rows: dict | None = None):
        self._city_rows = city_rows or _CITY_ROWS

    def connect(self):
        return _RankingMockConnection(self._city_rows)


def _base_state(message: str, memory: dict | None = None) -> AgentState:
    return AgentState(
        session_id="test-session",
        user_message=message,
        memory=memory or {},
        retry_count=0,
    )


def _run(message: str, memory: dict | None = None, city_rows: dict | None = None):
    graph = build_graph()
    llm = _RankingMockLLM()
    db = _RankingMockDBEngine(city_rows)
    state = _base_state(message, memory=memory)
    return graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})


# ===========================================================================
# Integration: the seven required end-to-end scenarios
# ===========================================================================

class TestRankingIntegration:
    """The seven required end-to-end ranking scenarios."""

    @pytest.mark.asyncio
    async def test_1_cheapest_apartments_in_berlin(self):
        """Show the 5 cheapest apartments in Berlin."""
        result = await _run("Show the 5 cheapest apartments in Berlin")
        msg = result.get("assistant_message", "")
        assert "cheapest" in msg.lower()
        assert "Berlin" in msg
        assert "wasn't able to complete" not in msg.lower()
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in msg

        props = result.get("properties", [])
        assert len(props) == 5
        # Verify ascending price order
        prices = [p["price"] for p in props]
        assert prices == sorted(prices), f"Prices not sorted ASC: {prices}"

    @pytest.mark.asyncio
    async def test_2_largest_houses_for_sale_in_paris(self):
        """What are the 3 largest houses for sale in Paris?"""
        result = await _run("What are the 3 largest houses for sale in Paris?")
        msg = result.get("assistant_message", "")
        assert "largest" in msg.lower()
        assert "Paris" in msg
        assert "wasn't able to complete" not in msg.lower()
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in msg

        props = result.get("properties", [])
        assert len(props) == 3
        # Verify descending size order
        sizes = [p["size_sqm"] for p in props]
        assert sizes == sorted(sizes, reverse=True), f"Sizes not sorted DESC: {sizes}"

        # Verify intent filter
        sql = result.get("generated_sql", "")
        assert "intent = 'buy'" in sql

    @pytest.mark.asyncio
    async def test_3_closest_properties_in_rome(self):
        """Show me the closest properties to the city centre in Rome."""
        result = await _run("Show me the closest properties to the city centre in Rome")
        msg = result.get("assistant_message", "")
        assert "closest" in msg.lower()
        assert "Rome" in msg
        assert "wasn't able to complete" not in msg.lower()
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in msg

        props = result.get("properties", [])
        assert len(props) > 0
        # Verify ascending distance order
        distances = [p["distance_from_city_km"] for p in props]
        assert distances == sorted(distances), f"Distances not sorted ASC: {distances}"

    @pytest.mark.asyncio
    async def test_4_closest_houses_in_amsterdam_within_10km(self):
        """Show the 5 closest houses in Amsterdam within 10km."""
        result = await _run("Show the 5 closest houses in Amsterdam within 10km")
        msg = result.get("assistant_message", "")
        assert "wasn't able to complete" not in msg.lower()
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in msg

        props = result.get("properties", [])
        # Amsterdam houses within 10km: distances 2.0, 5.0, 8.0 (12 and 15 exceed 10km)
        assert len(props) == 3
        for p in props:
            assert p["distance_from_city_km"] <= 10.0
        distances = [p["distance_from_city_km"] for p in props]
        assert distances == sorted(distances), f"Distances not sorted ASC: {distances}"

        sql = result.get("generated_sql", "")
        assert "distance_from_city_km <= 10" in sql

    @pytest.mark.asyncio
    async def test_5_no_stale_filter_leakage(self):
        """Ranking after an unrelated search does not leak stale filters."""
        # Memory from a prior search for rent in Amsterdam
        stale_memory = {
            "search_context": {
                "city": "Amsterdam",
                "intent": "rent",
                "property_type": "apartment",
                "bedrooms": 2,
                "max_price": 200000,
            }
        }
        result = await _run(
            "Show the 5 cheapest apartments in Berlin",
            memory=stale_memory,
        )
        sql = result.get("generated_sql", "")
        # Must use Berlin, not Amsterdam from stale memory
        assert "Berlin" in sql
        assert "Amsterdam" not in sql
        # Must not carry stale intent='rent' or bedrooms=2
        assert "bedrooms =" not in sql
        # Price ordering must be ASC, not inherited from stale context
        assert "ORDER BY price ASC" in sql

        msg = result.get("assistant_message", "")
        assert "Amsterdam" not in msg

    @pytest.mark.asyncio
    async def test_6_city_switch_honors_latest_city(self):
        """Ranking with explicit city switch honours the latest city only."""
        # Memory from a prior search in London
        london_memory = {
            "search_context": {
                "city": "London",
                "intent": "buy",
                "property_type": "house",
            }
        }
        result = await _run(
            "Show the 5 cheapest apartments in Berlin",
            memory=london_memory,
        )
        sql = result.get("generated_sql", "")
        assert "Berlin" in sql
        assert "London" not in sql
        # Must not carry stale property_type='house'
        assert "property_type = 'apartment'" in sql

    @pytest.mark.asyncio
    async def test_7_intent_switch_honors_latest_intent(self):
        """Ranking with explicit intent switch honours the latest intent only."""
        # Memory from a prior rent search
        rent_memory = {
            "search_context": {
                "city": "Paris",
                "intent": "rent",
                "property_type": "apartment",
            }
        }
        result = await _run(
            "What are the 3 largest houses for sale in Paris?",
            memory=rent_memory,
        )
        sql = result.get("generated_sql", "")
        # Must use buy (from "for sale"), not rent from stale memory
        assert "intent = 'buy'" in sql
        # Must use house, not apartment from stale memory
        assert "property_type = 'house'" in sql


# ===========================================================================
# Integration: routing guards
# ===========================================================================

class TestRankingRoutingGuards:
    """Ranking must never reach the free-form SQL generation path."""

    @pytest.mark.asyncio
    async def test_generated_sql_has_no_lat_lon(self):
        result = await _run("Show the 5 cheapest apartments in Berlin")
        sql = result.get("generated_sql", "")
        assert "latitude" not in sql.lower()
        assert "longitude" not in sql.lower()
        assert "city_centers" not in sql.lower()

    @pytest.mark.asyncio
    async def test_generated_sql_has_order_by_and_limit(self):
        result = await _run("Show the 5 cheapest apartments in Berlin")
        sql = result.get("generated_sql", "")
        assert "ORDER BY" in sql
        assert "LIMIT" in sql

    @pytest.mark.asyncio
    async def test_no_llm_fallback_text_in_answer(self):
        """The mock LLM emits a sentinel for any SQL/summary call. If the
        ranking path stayed deterministic, the sentinel never appears."""
        result = await _run("What are the 3 largest houses for sale in Paris?")
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in result.get("assistant_message", "")

    @pytest.mark.asyncio
    async def test_ranking_returns_property_cards(self):
        """Unlike count/aggregation/comparison, ranking returns property cards."""
        result = await _run("Show the 5 cheapest apartments in Berlin")
        props = result.get("properties", [])
        assert len(props) > 0
        # Each property should have expected fields
        for p in props:
            assert "id" in p
            assert "price" in p
            assert "city" in p

    @pytest.mark.asyncio
    async def test_result_count_matches_properties(self):
        result = await _run("Show the 5 cheapest apartments in Berlin")
        assert result.get("result_count") == len(result.get("properties", []))


# ===========================================================================
# Integration: no context leakage
# ===========================================================================

class TestNoRankingContextLeakage:
    """Stale filters from prior turns must never bleed into a ranking query."""

    @pytest.mark.asyncio
    async def test_prior_city_does_not_appear_in_sql(self):
        amsterdam_memory = {
            "search_context": {
                "city": "Amsterdam",
                "intent": "rent",
                "property_type": "apartment",
            }
        }
        result = await _run(
            "Show the 5 cheapest apartments in Berlin",
            memory=amsterdam_memory,
        )
        sql = result.get("generated_sql", "")
        assert "Berlin" in sql
        assert "Amsterdam" not in sql, f"City leakage — Amsterdam in SQL: {sql}"
        msg = result.get("assistant_message", "")
        assert "Amsterdam" not in msg, f"City leakage — Amsterdam in message: {msg}"

    @pytest.mark.asyncio
    async def test_prior_budget_does_not_leak(self):
        """A max_price from a prior search must not appear in a ranking that
        doesn't mention a budget."""
        budget_memory = {
            "search_context": {
                "city": "London",
                "max_price": 300000,
                "property_type": "apartment",
            }
        }
        result = await _run(
            "Show the most expensive apartments in London",
            memory=budget_memory,
        )
        sql = result.get("generated_sql", "")
        # The new query is for "most expensive" — no budget filter
        assert "price <=" not in sql, f"Budget leakage in SQL: {sql}"

    @pytest.mark.asyncio
    async def test_prior_bedrooms_does_not_leak(self):
        """Bedrooms from a prior search must not appear in a ranking that
        doesn't mention bedrooms."""
        bed_memory = {
            "search_context": {
                "city": "Berlin",
                "bedrooms": 3,
                "property_type": "house",
            }
        }
        result = await _run(
            "Show the 5 cheapest apartments in Berlin",
            memory=bed_memory,
        )
        sql = result.get("generated_sql", "")
        assert "bedrooms =" not in sql, f"Bedrooms leakage in SQL: {sql}"
        assert "property_type = 'apartment'" in sql
