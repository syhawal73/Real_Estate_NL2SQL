"""Tests for the deterministic COMPARISON query path (Sprint 3.x).

COVERAGE
--------
Unit tests (no DB, no LLM):
  TestParseComparisonRequest   — entity/dimension/filter extraction, leakage guard
  TestBuildComparisonQuery     — two per-city SQLs, correct columns, no lat/lon
  TestComparisonValidation     — both built SQLs pass the shared SQL validator
  TestCompareResults           — winner / tie / no-results logic per dimension
  TestFormatComparisonMessage  — numeric, SQL-free, both-values answers

Integration tests (full graph, mock LLM + city-aware mock DB):
  TestComparisonIntegration    — the six required end-to-end scenarios
  TestComparisonRoutingGuards  — comparison never uses the free-form SQL path
  TestNoComparisonCityLeakage  — prior-turn city never bleeds into a comparison

REQUIRED CASES (from the ticket)
--------------------------------
  1. Compare average sale prices in London vs Berlin
  2. Which city has more rental apartments, Paris or Amsterdam?
  3. Compare the cheapest apartments in Rome and Paris
  4. Compare houses in Berlin vs London by average price
  5. Comparison where one city has zero matches
  6. Comparison where both cities have the same value

SUCCESS CRITERIA
----------------
- Deterministic comparison results (same input → same output).
- No wrong intent mapping; correct property_type / intent filters.
- No stale context leakage from prior turns.
- No generic "unable to complete" for supported cases.
- No fallback to free-form SQL generation for comparison queries.
"""

from __future__ import annotations

import json

import pytest

from app.agents.free_chat.query_builders import (
    CMP_NO_RESULTS_BOTH,
    CMP_NO_RESULTS_LEFT,
    CMP_NO_RESULTS_RIGHT,
    CMP_OK,
    CMP_TIE,
    DIM_AVG,
    DIM_COUNT,
    DIM_MAX,
    DIM_MIN,
    build_comparison_query,
    compare_comparison_results,
    format_comparison_message,
    parse_comparison_request,
)
from app.agents.free_chat.utils import validate_sql


# ===========================================================================
# Unit: parse_comparison_request
# ===========================================================================

class TestParseComparisonRequest:
    """Entity, dimension and shared-filter extraction from the user message."""

    def test_average_sale_prices_london_vs_berlin(self):
        r = parse_comparison_request("Compare average sale prices in London vs Berlin")
        assert r.ok is True
        assert r.left_city == "London"
        assert r.right_city == "Berlin"
        assert r.dimension == DIM_AVG
        assert r.intent == "buy"          # "sale" → buy

    def test_more_rental_apartments_paris_or_amsterdam(self):
        r = parse_comparison_request(
            "Which city has more rental apartments, Paris or Amsterdam?"
        )
        assert r.ok is True
        assert r.left_city == "Paris"
        assert r.right_city == "Amsterdam"
        assert r.dimension == DIM_COUNT   # "more <noun>" → count
        assert r.property_type == "apartment"
        assert r.intent == "rent"         # "rental" → rent

    def test_cheapest_apartments_rome_and_paris(self):
        r = parse_comparison_request("Compare the cheapest apartments in Rome and Paris")
        assert r.ok is True
        assert r.left_city == "Rome"
        assert r.right_city == "Paris"
        assert r.dimension == DIM_MIN     # "cheapest" → min
        assert r.property_type == "apartment"

    def test_houses_berlin_vs_london_by_average_price(self):
        r = parse_comparison_request("Compare houses in Berlin vs London by average price")
        assert r.ok is True
        assert r.left_city == "Berlin"
        assert r.right_city == "London"
        assert r.dimension == DIM_AVG
        assert r.property_type == "house"

    def test_more_expensive_on_average_resolves_to_avg(self):
        r = parse_comparison_request(
            "Are houses in Berlin or London more expensive on average?"
        )
        assert r.ok is True
        assert r.dimension == DIM_AVG     # 'more expensive' + 'on average' → avg
        assert r.property_type == "house"

    def test_highest_priced_house_resolves_to_max(self):
        r = parse_comparison_request("Which has the most expensive house, Rome or Paris?")
        assert r.ok is True
        assert r.dimension == DIM_MAX
        assert r.property_type == "house"

    def test_order_of_cities_is_preserved(self):
        r = parse_comparison_request("Compare prices in Amsterdam and Rome")
        assert r.left_city == "Amsterdam"
        assert r.right_city == "Rome"

    def test_only_first_two_distinct_cities_used(self):
        r = parse_comparison_request("Compare London, Paris and Berlin average prices")
        assert r.ok is True
        assert r.left_city == "London"
        assert r.right_city == "Paris"

    def test_one_city_returns_clear_error(self):
        r = parse_comparison_request("Compare average prices in London")
        assert r.ok is False
        assert r.error
        assert "London" in r.error

    def test_no_city_returns_clear_error(self):
        r = parse_comparison_request("Compare average prices please")
        assert r.ok is False
        assert r.error
        assert "two cities" in r.error.lower()

    def test_empty_message_returns_error(self):
        r = parse_comparison_request("")
        assert r.ok is False
        assert r.error

    def test_default_dimension_is_avg(self):
        r = parse_comparison_request("Compare Rome and Paris")
        assert r.ok is True
        assert r.dimension == DIM_AVG

    def test_does_not_read_prior_context(self):
        """parse_comparison_request takes only the message — no context arg,
        so a prior-turn city physically cannot leak in."""
        r = parse_comparison_request("Compare Rome and Paris")
        assert r.left_city == "Rome"
        assert r.right_city == "Paris"
        # No 'Berlin'/'London' invented from nowhere
        assert "Berlin" not in (r.left_city, r.right_city)
        assert "London" not in (r.left_city, r.right_city)

    def test_deterministic_repeatable(self):
        msg = "Which city has more rental apartments, Paris or Amsterdam?"
        r1 = parse_comparison_request(msg)
        r2 = parse_comparison_request(msg)
        assert (r1.left_city, r1.right_city, r1.dimension, r1.property_type, r1.intent) == \
               (r2.left_city, r2.right_city, r2.dimension, r2.property_type, r2.intent)


# ===========================================================================
# Unit: build_comparison_query
# ===========================================================================

class TestBuildComparisonQuery:
    """Two per-city SQLs, correct value columns, no coordinate joins."""

    def test_avg_builds_two_avg_queries(self):
        r = parse_comparison_request("Compare average sale prices in London vs Berlin")
        plan = build_comparison_query(r)
        assert plan.dimension == DIM_AVG
        assert plan.value_column == "avg_price"
        assert "AVG(PRICE)" in plan.left.sql.upper()
        assert "AVG(PRICE)" in plan.right.sql.upper()
        assert "city = 'London'" in plan.left.sql
        assert "city = 'Berlin'" in plan.right.sql
        # shared intent 'buy' applied to both sides
        assert "intent = 'buy'" in plan.left.sql
        assert "intent = 'buy'" in plan.right.sql

    def test_count_builds_two_count_queries(self):
        r = parse_comparison_request(
            "Which city has more rental apartments, Paris or Amsterdam?"
        )
        plan = build_comparison_query(r)
        assert plan.dimension == DIM_COUNT
        assert plan.value_column == "property_count"
        assert "COUNT(*)" in plan.left.sql.upper()
        assert "COUNT(*)" in plan.right.sql.upper()
        assert "city = 'Paris'" in plan.left.sql
        assert "city = 'Amsterdam'" in plan.right.sql
        assert "property_type = 'apartment'" in plan.left.sql
        assert "intent = 'rent'" in plan.right.sql

    def test_min_builds_two_min_queries(self):
        r = parse_comparison_request("Compare the cheapest apartments in Rome and Paris")
        plan = build_comparison_query(r)
        assert plan.dimension == DIM_MIN
        assert plan.value_column == "min_price"
        assert "MIN(PRICE)" in plan.left.sql.upper()
        assert "MIN(PRICE)" in plan.right.sql.upper()

    def test_max_builds_two_max_queries(self):
        r = parse_comparison_request("Which has the most expensive house, Rome or Paris?")
        plan = build_comparison_query(r)
        assert plan.dimension == DIM_MAX
        assert plan.value_column == "max_price"
        assert "MAX(PRICE)" in plan.left.sql.upper()
        assert "MAX(PRICE)" in plan.right.sql.upper()

    def test_no_latitude_longitude_or_city_centers(self):
        r = parse_comparison_request("Compare average sale prices in London vs Berlin")
        plan = build_comparison_query(r)
        for sql in (plan.left.sql, plan.right.sql):
            assert "latitude" not in sql.lower()
            assert "longitude" not in sql.lower()
            assert "city_centers" not in sql.lower()
            assert "join" not in sql.lower()

    def test_no_invented_filters(self):
        """Only city + (optional) property_type + intent should appear — no
        bedrooms/price/etc. invented from nowhere."""
        r = parse_comparison_request("Compare average prices in Rome and Paris")
        plan = build_comparison_query(r)
        for sql in (plan.left.sql, plan.right.sql):
            assert "bedrooms" not in sql.lower()
            assert "bathrooms" not in sql.lower()
            assert "price <=" not in sql.lower()

    def test_intent_never_becomes_sell(self):
        r = parse_comparison_request("Compare average sale prices in London vs Berlin")
        plan = build_comparison_query(r)
        assert "sell" not in plan.left.sql.lower()
        assert "sell" not in plan.right.sql.lower()
        assert "intent = 'buy'" in plan.left.sql

    def test_build_on_invalid_request_raises(self):
        r = parse_comparison_request("Compare prices in London")  # one city
        assert r.ok is False
        with pytest.raises(ValueError):
            build_comparison_query(r)


# ===========================================================================
# Unit: both SQLs pass the shared validator
# ===========================================================================

class TestComparisonValidation:
    """Every comparison SQL must pass validate_sql (same gate as other paths)."""

    def _assert_both_valid(self, message: str):
        plan = build_comparison_query(parse_comparison_request(message))
        for side in (plan.left, plan.right):
            ok, err = validate_sql(side.sql)
            assert ok, f"SQL failed validation: {err}\nSQL: {side.sql}"

    def test_avg_sale_prices_valid(self):
        self._assert_both_valid("Compare average sale prices in London vs Berlin")

    def test_count_rentals_valid(self):
        self._assert_both_valid(
            "Which city has more rental apartments, Paris or Amsterdam?"
        )

    def test_cheapest_apartments_valid(self):
        self._assert_both_valid("Compare the cheapest apartments in Rome and Paris")

    def test_houses_avg_valid(self):
        self._assert_both_valid("Compare houses in Berlin vs London by average price")


# ===========================================================================
# Unit: compare_comparison_results
# ===========================================================================

def _plan(message: str):
    return build_comparison_query(parse_comparison_request(message))


class TestCompareResults:
    """Winner / tie / no-results determination per dimension."""

    # ── count ────────────────────────────────────────────────────────────
    def test_count_larger_wins(self):
        plan = _plan("Which city has more rental apartments, Paris or Amsterdam?")
        res = compare_comparison_results(plan, 17, 9)
        assert res.status == CMP_OK
        assert res.winner == "Paris"
        assert res.left_value == 17
        assert res.right_value == 9

    def test_count_zero_match_other_side_wins(self):
        plan = _plan("Which city has more rental apartments, Paris or Amsterdam?")
        res = compare_comparison_results(plan, 17, 0)   # Amsterdam zero
        assert res.status == CMP_OK
        assert res.winner == "Paris"
        assert res.right_value == 0

    def test_count_both_zero_is_tie(self):
        plan = _plan("Which city has more rental apartments, Paris or Amsterdam?")
        res = compare_comparison_results(plan, 0, 0)
        assert res.status == CMP_TIE
        assert res.winner is None

    def test_count_null_coerced_to_zero(self):
        plan = _plan("Which city has more rental apartments, Paris or Amsterdam?")
        res = compare_comparison_results(plan, 5, None)
        assert res.right_value == 0
        assert res.winner == "Paris"

    # ── average ──────────────────────────────────────────────────────────
    def test_avg_higher_wins(self):
        plan = _plan("Compare average sale prices in London vs Berlin")
        res = compare_comparison_results(plan, 600000, 450000)
        assert res.status == CMP_OK
        assert res.winner == "London"

    def test_avg_tie(self):
        plan = _plan("Compare average prices in Rome and Paris")
        res = compare_comparison_results(plan, 400000, 400000)
        assert res.status == CMP_TIE
        assert res.winner is None

    def test_avg_no_results_left(self):
        plan = _plan("Compare average prices in Rome and Paris")
        res = compare_comparison_results(plan, None, 400000)
        assert res.status == CMP_NO_RESULTS_LEFT
        assert res.winner == "Paris"

    def test_avg_no_results_right(self):
        plan = _plan("Compare average prices in Rome and Paris")
        res = compare_comparison_results(plan, 400000, None)
        assert res.status == CMP_NO_RESULTS_RIGHT
        assert res.winner == "Rome"

    def test_avg_no_results_both(self):
        plan = _plan("Compare average prices in Rome and Paris")
        res = compare_comparison_results(plan, None, None)
        assert res.status == CMP_NO_RESULTS_BOTH
        assert res.winner is None

    # ── min ──────────────────────────────────────────────────────────────
    def test_min_lower_wins(self):
        plan = _plan("Compare the cheapest apartments in Rome and Paris")
        res = compare_comparison_results(plan, 280000, 310000)
        assert res.status == CMP_OK
        assert res.winner == "Rome"          # cheaper wins

    def test_min_tie(self):
        plan = _plan("Compare the cheapest apartments in Rome and Paris")
        res = compare_comparison_results(plan, 300000, 300000)
        assert res.status == CMP_TIE

    # ── max ──────────────────────────────────────────────────────────────
    def test_max_higher_wins(self):
        plan = _plan("Which has the most expensive house, Rome or Paris?")
        res = compare_comparison_results(plan, 900000, 750000)
        assert res.winner == "Rome"

    def test_deterministic(self):
        plan = _plan("Compare average sale prices in London vs Berlin")
        r1 = compare_comparison_results(plan, 600000, 450000)
        r2 = compare_comparison_results(plan, 600000, 450000)
        assert (r1.status, r1.winner) == (r2.status, r2.winner)


# ===========================================================================
# Unit: format_comparison_message
# ===========================================================================

class TestFormatComparisonMessage:
    """Answers are numeric, SQL-free, and report both sides."""

    def _msg(self, message, left, right):
        plan = _plan(message)
        return format_comparison_message(compare_comparison_results(plan, left, right))

    def test_avg_message_has_both_values_and_winner(self):
        msg = self._msg("Compare average sale prices in London vs Berlin", 600000, 450000)
        assert "London" in msg and "Berlin" in msg
        assert "600,000" in msg
        assert "450,000" in msg
        assert "£" in msg          # London → GBP
        assert "€" in msg          # Berlin → EUR

    def test_count_message_names_winner(self):
        msg = self._msg(
            "Which city has more rental apartments, Paris or Amsterdam?", 17, 9
        )
        assert "Paris" in msg
        assert "17" in msg
        assert "9" in msg
        assert "more" in msg.lower()

    def test_count_zero_match_message(self):
        msg = self._msg(
            "Which city has more rental apartments, Paris or Amsterdam?", 17, 0
        )
        assert "Paris" in msg
        assert "Amsterdam" in msg
        assert "none" in msg.lower() or "0" in msg

    def test_cheapest_message(self):
        msg = self._msg("Compare the cheapest apartments in Rome and Paris", 280000, 310000)
        assert "Rome" in msg
        assert "cheaper" in msg.lower()
        assert "280,000" in msg
        assert "310,000" in msg

    def test_tie_message(self):
        msg = self._msg("Compare average prices in Rome and Paris", 400000, 400000)
        assert "tie" in msg.lower()
        assert "400,000" in msg

    def test_no_results_one_side_message(self):
        msg = self._msg("Compare average prices in Rome and Paris", None, 400000)
        assert "Rome" in msg
        assert "couldn't find" in msg.lower() or "no " in msg.lower()
        assert "400,000" in msg

    def test_message_never_contains_sql(self):
        for left, right in [(600000, 450000), (None, 400000), (400000, 400000)]:
            msg = self._msg("Compare average prices in Rome and Paris", left, right)
            assert "SELECT" not in msg.upper()
            assert "FROM" not in msg.upper()
            assert "WHERE" not in msg.upper()
            assert "AVG" not in msg.upper()


# ===========================================================================
# Integration: full graph with mock LLM + city-aware mock DB
# ===========================================================================
from app.agents.free_chat.graph import build_graph
from app.agents.free_chat.state import AgentState
from app.infrastructure.llm.base import LLMProvider


class _ComparisonMockLLM(LLMProvider):
    """Mock LLM that always classifies the turn as a COMPARISON.

    The comparison path does NOT call the LLM for SQL or summary — it is
    fully deterministic — so only the classify_intent / classify_action /
    extract_constraints calls matter here.
    """

    async def invoke(self, messages: list, **kwargs) -> str:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return json.dumps({"action": "new_search"})
        if "query classifier" in system or "intent" in system:
            return json.dumps({"intent": "comparison"})
        if "parameter extractor" in system or "extractor" in system:
            return json.dumps({})
        # If the comparison path ever wrongly reached an LLM summary/SQL node,
        # this sentinel would leak into the output and fail the assertions.
        return "LLM_FALLBACK_SHOULD_NOT_APPEAR"

    async def invoke_json(self, messages: list, **kwargs) -> dict:
        system = (messages[0]["content"] if messages else "").lower()
        if "conversation classifier" in system:
            return {"action": "new_search"}
        if "query classifier" in system or "intent" in system:
            return {"intent": "comparison"}
        if "parameter extractor" in system or "extractor" in system:
            return {}
        return {}


class _CityAwareResult:
    """SQLAlchemy CursorResult stand-in returning a single (value,) row."""

    def __init__(self, column: str, value):
        self._column = column
        self._value = value

    def keys(self):
        return [self._column]

    def fetchmany(self, n=50):
        if self._value is _NO_ROW:
            return []
        return [(self._value,)]


_NO_ROW = object()  # sentinel: query returned no row at all


class _CityAwareConnection:
    """Connection whose execute() inspects the SQL to pick a per-city value.

    ``value_map`` maps a city name → scalar value. A value of ``_NO_ROW``
    makes the query return zero rows (used to simulate NULL aggregates).
    ``column`` is the result column name the comparison node reads.
    """

    def __init__(self, value_map: dict, column: str):
        self._value_map = value_map
        self._column = column

    async def execute(self, query):
        sql = str(query)
        chosen_city = None
        for city in self._value_map:
            if f"city = '{city}'" in sql:
                chosen_city = city
                break
        value = self._value_map.get(chosen_city, 0)
        return _CityAwareResult(self._column, value)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


class _CityAwareDBEngine:
    """Mock engine that returns city-specific scalar values per query."""

    def __init__(self, value_map: dict, column: str):
        self._value_map = value_map
        self._column = column

    def connect(self):
        return _CityAwareConnection(self._value_map, self._column)


def _base_state(message: str, memory: dict | None = None) -> AgentState:
    return AgentState(
        session_id="test-session",
        user_message=message,
        memory=memory or {},
        retry_count=0,
    )


def _run(message: str, value_map: dict, column: str, memory: dict | None = None):
    graph = build_graph()
    llm = _ComparisonMockLLM()
    db = _CityAwareDBEngine(value_map, column)
    state = _base_state(message, memory=memory)
    return graph.ainvoke(state, config={"configurable": {"llm": llm, "db_engine": db}})


class TestComparisonIntegration:
    """The six required end-to-end comparison scenarios."""

    @pytest.mark.asyncio
    async def test_1_average_sale_prices_london_vs_berlin(self):
        result = await _run(
            "Compare average sale prices in London vs Berlin",
            {"London": 850000, "Berlin": 450000},
            "avg_price",
        )
        msg = result.get("assistant_message", "")
        assert "London" in msg and "Berlin" in msg
        assert "850,000" in msg and "450,000" in msg
        assert "wasn't able to complete" not in msg.lower()
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in msg
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_2_more_rental_apartments_paris_or_amsterdam(self):
        result = await _run(
            "Which city has more rental apartments, Paris or Amsterdam?",
            {"Paris": 17, "Amsterdam": 9},
            "property_count",
        )
        msg = result.get("assistant_message", "")
        assert "Paris" in msg
        assert "17" in msg and "9" in msg
        assert "more" in msg.lower()
        assert "wasn't able to complete" not in msg.lower()
        assert result.get("properties", []) == []

    @pytest.mark.asyncio
    async def test_3_cheapest_apartments_rome_and_paris(self):
        result = await _run(
            "Compare the cheapest apartments in Rome and Paris",
            {"Rome": 280000, "Paris": 310000},
            "min_price",
        )
        msg = result.get("assistant_message", "")
        assert "Rome" in msg
        assert "280,000" in msg and "310,000" in msg
        assert "cheaper" in msg.lower()
        assert "wasn't able to complete" not in msg.lower()

    @pytest.mark.asyncio
    async def test_4_houses_berlin_vs_london_by_average(self):
        result = await _run(
            "Compare houses in Berlin vs London by average price",
            {"Berlin": 500000, "London": 850000},
            "avg_price",
        )
        msg = result.get("assistant_message", "")
        # London higher → London wins
        assert "London" in msg and "Berlin" in msg
        assert "850,000" in msg and "500,000" in msg
        assert "wasn't able to complete" not in msg.lower()

    @pytest.mark.asyncio
    async def test_5_one_city_zero_matches(self):
        # Amsterdam has zero rental apartments.
        result = await _run(
            "Which city has more rental apartments, Paris or Amsterdam?",
            {"Paris": 12, "Amsterdam": 0},
            "property_count",
        )
        msg = result.get("assistant_message", "")
        assert "Paris" in msg
        assert "Amsterdam" in msg
        assert "12" in msg
        assert "none" in msg.lower() or "0" in msg
        assert "wasn't able to complete" not in msg.lower()

    @pytest.mark.asyncio
    async def test_5b_extrema_null_one_side(self):
        # Price dimension where one city has no matching rows (NULL aggregate).
        result = await _run(
            "Compare the cheapest apartments in Rome and Paris",
            {"Rome": 280000, "Paris": _NO_ROW},
            "min_price",
        )
        msg = result.get("assistant_message", "")
        assert "Paris" in msg
        assert "couldn't find" in msg.lower() or "no " in msg.lower()
        assert "280,000" in msg          # Rome value still reported
        assert "wasn't able to complete" not in msg.lower()

    @pytest.mark.asyncio
    async def test_6_both_cities_same_value(self):
        result = await _run(
            "Compare average prices in Rome and Paris",
            {"Rome": 400000, "Paris": 400000},
            "avg_price",
        )
        msg = result.get("assistant_message", "")
        assert "tie" in msg.lower()
        assert "400,000" in msg
        assert "wasn't able to complete" not in msg.lower()


class TestComparisonRoutingGuards:
    """Comparison must never reach the free-form SQL generation path."""

    @pytest.mark.asyncio
    async def test_generated_sql_has_no_lat_lon(self):
        result = await _run(
            "Compare average sale prices in London vs Berlin",
            {"London": 850000, "Berlin": 450000},
            "avg_price",
        )
        sql = result.get("generated_sql", "")
        assert "latitude" not in sql.lower()
        assert "longitude" not in sql.lower()
        assert "city_centers" not in sql.lower()

    @pytest.mark.asyncio
    async def test_generated_sql_contains_both_cities(self):
        result = await _run(
            "Compare average sale prices in London vs Berlin",
            {"London": 850000, "Berlin": 450000},
            "avg_price",
        )
        sql = result.get("generated_sql", "")
        assert "London" in sql and "Berlin" in sql

    @pytest.mark.asyncio
    async def test_no_llm_fallback_text_in_answer(self):
        """The mock LLM emits a sentinel for any SQL/summary call. If the
        comparison path stayed deterministic, the sentinel never appears."""
        result = await _run(
            "Compare the cheapest apartments in Rome and Paris",
            {"Rome": 280000, "Paris": 310000},
            "min_price",
        )
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in result.get("assistant_message", "")

    @pytest.mark.asyncio
    async def test_one_city_request_gives_clear_message_not_error(self):
        result = await _run(
            "Compare average prices in London",   # only one city
            {"London": 850000},
            "avg_price",
        )
        msg = result.get("assistant_message", "")
        assert msg                                  # non-empty, friendly
        assert "wasn't able to complete" not in msg.lower()
        assert "LLM_FALLBACK_SHOULD_NOT_APPEAR" not in msg


class TestNoComparisonCityLeakage:
    """A city from a previous turn must never bleed into a fresh comparison."""

    @pytest.mark.asyncio
    async def test_prior_city_does_not_appear(self):
        # Memory carries Amsterdam from a prior session; the new comparison
        # is strictly Rome vs Paris and must not mention/seek Amsterdam.
        amsterdam_memory = {
            "search_context": {
                "city": "Amsterdam",
                "intent": "rent",
                "property_type": "apartment",
            }
        }
        result = await _run(
            "Compare average prices in Rome and Paris",
            {"Rome": 400000, "Paris": 500000},
            "avg_price",
            memory=amsterdam_memory,
        )
        sql = result.get("generated_sql", "")
        assert "Rome" in sql and "Paris" in sql
        assert "Amsterdam" not in sql, f"City leakage — Amsterdam in SQL: {sql}"
        msg = result.get("assistant_message", "")
        assert "Amsterdam" not in msg, f"City leakage — Amsterdam in message: {msg}"
