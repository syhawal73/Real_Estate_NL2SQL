"""Node: build_deterministic_query — bypasses LLM SQL generation for
COUNT and AGGREGATION intents (Sprint 3 SQL-builder ticket).

WHEN THIS NODE RUNS
-------------------
The graph routes COUNT and AGGREGATION intents here instead of
``generate_sql_node``.  It reads from ``state.search_context`` (structured
SearchContext) and produces a validated SQL string without any LLM call.

This eliminates:
- Wrong intent mapping (e.g. sell instead of buy) from LLM hallucination
- Partial text responses returned as the final answer
- SQL referencing nonexistent columns (longitude, latitude on properties)
- Generic fallback error messages for supported query types

OUTPUT
------
Sets ``state.generated_sql``, ``state.sql_valid``, and ``state.sql_error``.
If the query cannot be built (e.g. schema validation rejects it), the node
marks ``sql_valid=False`` and sets an informative ``sql_error`` so the
graph's existing retry/error path handles it cleanly.

After this node the graph continues to ``validate_sql`` → ``execute_query``
→ ``summarize`` exactly as for LLM-generated SQL, so no graph topology
changes are required.
"""

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.query_builders import build_aggregation_query, build_count_query
from app.agents.free_chat.state import AgentState
from app.agents.free_chat.utils import validate_sql
from app.domain.chat.schemas import QueryIntent, SearchContext


async def build_deterministic_query_node(
    state: AgentState,
    config: RunnableConfig,
) -> dict:
    """Build a deterministic COUNT or AGGREGATION SQL query.

    Reads ``state.search_context`` and ``state.intent`` to pick the correct
    builder, then validates the result with the existing SQL validator.

    The node is intentionally synchronous in nature (no I/O) but declared
    ``async`` to match the LangGraph node contract.
    """
    intent = state.get("intent", "")
    user_message = state.get("user_message", "")
    search_context = SearchContext(**(state.get("search_context") or {}))

    # ── Build SQL based on intent ─────────────────────────────────────────
    if intent == QueryIntent.COUNT.value:
        sql = build_count_query(search_context, user_message)
    elif intent == QueryIntent.AGGREGATION.value:
        sql = build_aggregation_query(search_context, user_message)
    else:
        # Should not happen due to graph routing, but be defensive.
        return {
            "generated_sql": "",
            "sql_valid": False,
            "sql_error": (
                f"build_deterministic_query_node called with unsupported intent "
                f"'{intent}'. Expected 'count' or 'aggregation'."
            ),
            "retry_count": state.get("retry_count", 0),
        }

    # ── Validate the built SQL via the shared validator ──────────────────
    is_valid, error = validate_sql(sql)

    return {
        "generated_sql": sql,
        "sql_valid": is_valid,
        "sql_error": error if not is_valid else "",
        "retry_count": state.get("retry_count", 0),
    }
