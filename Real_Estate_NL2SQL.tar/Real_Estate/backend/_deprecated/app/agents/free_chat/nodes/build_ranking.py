"""Node: build_ranking_query — deterministic top-N RANKING path.

WHEN THIS NODE RUNS
-------------------
The graph routes the RANKING intent here instead of ``generate_sql``.
This guarantees ranking questions never fall back to free-form LLM SQL
generation (the brittle path that produced wrong parameters, stale
filters, and empty results in prior failure reports).

WHAT IT DOES
------------
Unlike COUNT / AGGREGATION (which need a single scalar and reuse the
shared validate → execute → summarize pipeline), a ranking query needs
to:
  1. Parse ranking entities from the CURRENT message only (no prior
     context, so stale filters can never leak in).
  2. Build a deterministic ORDER BY … LIMIT N query over the properties
     table using only existing schema columns.
  3. Execute the query and collect the property rows.
  4. Format a deterministic summary message describing the ranking.

This node owns the complete sub-flow (build + execute + format), the
same self-contained pattern as the comparison node.

OUTPUT
------
Sets ``assistant_message`` (the summary), ``properties`` (the ranked
property cards), ``generated_sql`` (for memory/debug), ``result_count``,
and writes a fresh ``search_context`` / ``active_search`` derived from
the parsed request (not from prior state).

The graph routes this node straight to ``update_memory`` → END so the
generic SQL pipeline is bypassed entirely.
"""

from langchain_core.runnables import RunnableConfig
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from app.agents.free_chat.query_builders import (
    build_ranking_query,
    format_ranking_message,
    parse_ranking_request,
)
from app.agents.free_chat.state import AgentState
from app.agents.free_chat.utils import rows_to_dicts, validate_sql
from app.domain.chat.schemas import ActiveSearchSession, SearchContext

_MAX_ROWS = 50


def _search_context_from_ranking(request) -> SearchContext:
    """Build a fresh SearchContext from the parsed ranking request.

    This is written to state so update_memory persists the correct
    filters for this turn — derived entirely from the current message,
    not from any prior state.
    """
    return SearchContext(
        city=request.city,
        intent=request.intent,
        property_type=request.property_type,
        bedrooms=request.bedrooms,
        max_price=request.max_price,
        radius_km=request.radius_km,
        sort_by=request.rank_by,
        sort_order=request.rank_order,
        limit=request.limit,
    )


async def build_ranking_query_node(
    state: AgentState,
    config: RunnableConfig,
) -> dict:
    """Build, execute and format a deterministic ranking query."""
    user_message = state.get("user_message", "")

    # ── 1. Parse ranking entities from the CURRENT message only ──────────
    request = parse_ranking_request(user_message)
    if not request.ok:
        return {
            "assistant_message": request.error,
            "properties": [],
            "result_count": 0,
            "generated_sql": "",
        }

    # ── 2. Build the deterministic SQL ───────────────────────────────────
    sql = build_ranking_query(request)

    # Defensive: SQL must pass the shared validator.
    ok, err = validate_sql(sql)
    if not ok:
        return {
            "assistant_message": (
                "I wasn't able to build a valid ranking query for that request. "
                "Try asking for the cheapest, largest, or closest properties "
                "in a specific city."
            ),
            "properties": [],
            "result_count": 0,
            "generated_sql": sql,
            "error_message": err,
        }

    engine: AsyncEngine = config["configurable"]["db_engine"]

    # ── 3. Execute ───────────────────────────────────────────────────────
    try:
        async with engine.connect() as conn:
            result = await conn.execute(text(sql))
            keys = list(result.keys())
            rows = result.fetchmany(_MAX_ROWS)
            data = rows_to_dicts(rows, keys)
    except Exception as exc:  # pragma: no cover — defensive DB error path
        return {
            "assistant_message": (
                "I ran into a problem running that ranking query. Please try "
                "rephrasing — for example, 'Show the 5 cheapest apartments "
                "in Berlin'."
            ),
            "properties": [],
            "result_count": 0,
            "generated_sql": sql,
            "error_message": str(exc),
        }

    # ── 4. Format results ────────────────────────────────────────────────
    message = format_ranking_message(request, data)

    # Build a fresh SearchContext from the ranking request (not from prior
    # state) so update_memory persists the correct filters for this turn.
    ranking_context = _search_context_from_ranking(request)
    active_session = ActiveSearchSession.from_search_context(
        ranking_context, search_id=None,
    )

    return {
        "assistant_message": message,
        "properties": data,
        "result_count": len(data),
        "generated_sql": sql,
        "error_message": "",
        # Fresh context derived from this turn's ranking request only.
        "search_context": ranking_context.model_dump(),
        "active_search": active_session.model_dump(),
    }
