"""Node: clarify — generates a clarifying question (Phase 4.1).

Phase 4.1: Uses pre-set question from needs_clarification node when available.
Only calls LLM if no question was pre-generated.
"""

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.prompts import CLARIFY_SYSTEM, CLARIFY_USER
from app.agents.free_chat.state import AgentState
from app.domain.chat.schemas import SearchContext
from app.infrastructure.llm.base import LLMProvider


async def clarify_node(state: AgentState, config: RunnableConfig) -> dict:
    # If needs_clarification already set a question, use it directly
    pre_set_question = state.get("clarification_question")
    if pre_set_question:
        return {
            "clarification_needed": True,
            "clarification_question": pre_set_question,
            "assistant_message": pre_set_question,
            "properties": [],
            "result_count": 0,
        }

    # Otherwise, generate via LLM
    llm: LLMProvider = config["configurable"]["llm"]
    search_context = SearchContext(**(state.get("search_context") or {}))

    messages = [
        {"role": "system", "content": CLARIFY_SYSTEM},
        {
            "role": "user",
            "content": CLARIFY_USER.format(
                user_message=state["user_message"],
                context=search_context.to_context_string(),
            ),
        },
    ]

    question = await llm.invoke(messages)
    question = question.strip()

    return {
        "clarification_needed": True,
        "clarification_question": question,
        "assistant_message": question,
        "properties": [],
        "result_count": 0,
    }

