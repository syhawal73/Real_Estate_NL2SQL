"""Node: handle_error — graceful fallback for unsupported queries and failures."""

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.prompts import ERROR_TEMPLATE, UNSUPPORTED_TEMPLATE
from app.agents.free_chat.state import AgentState


async def handle_error_node(state: AgentState, config: RunnableConfig) -> dict:
    intent = state.get("intent", "")

    if intent == "unsupported":
        message = UNSUPPORTED_TEMPLATE
    else:
        # SQL retry exhausted or unexpected error
        error = state.get("sql_error", "")
        message = ERROR_TEMPLATE
        if error:
            message += f" (Details: {error[:120]})"

    return {
        "assistant_message": message,
        "properties": [],
        "result_count": 0,
        "error_message": state.get("sql_error", ""),
        "clarification_needed": False,
    }
