"""Node: build_comparison_query — deterministic city-vs-city COMPARISON path.

WHEN THIS NODE RUNS
-------------------
The graph routes the COMPARISON intent here instead of ``generate_sql``.
This guarantees comparison questions never fall back to free-form LLM SQL
generation (the brittle path that produced wrong intents, wrong property
types, and mismatched filters in prior test reports).

WHAT IT DOES
------------
Unlike COUNT / AGGREGATION (which need a single query and reuse the shared
validate → execute → summarize pipeline), a comparison needs **two** queries
— one per city — and a comparison of their scalar results.  This node owns
that whole sub-flow:

  1. parse_comparison_request  — extract the two cities, the comparison
     dimension (count / avg / min / max price) and any shared
     property_type / intent filter, **from the current message only** so a
     prior-turn city can never leak in.
  2. build_comparison_query    — build two deterministic single-table SQLs
     (reusing build_count_query / aggregation builders).
  3. execute both              — run each SQL against the same engine the
     execute_query node uses, pulling the single scalar per side.
  4. compare + format          — determine winner / tie / no-results and
     render a numeric, SQL-free answer.

OUTPUT
------
Sets ``assistant_message`` (the final answer), ``properties`` (always empty
for comparisons), ``generated_sql`` (both SQLs, for memory/debug), and
``result_count``.  The graph routes this node straight to ``update_memory``
→ END, so the generic SQL pipeline is bypassed entirely.

If the request can't be resolved into a valid two-city comparison, the node
returns a clear, friendly message (it does not raise, and it does not invoke
the LLM).
"""

from langchain_core.runnables import RunnableConfig
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

from app.agents.free_chat.query_builders import (
    ComparisonPlan,
    build_comparison_query,
    compare_comparison_results,
    format_comparison_message,
    parse_comparison_request,
)
from app.agents.free_chat.state import AgentState
from app.agents.free_chat.utils import rows_to_dicts, validate_sql


async def _execute_scalar(engine: AsyncEngine, sql: str, value_column: str):
    """Execute a single-row aggregate/count query and return its scalar value.

    Returns the value from ``value_column`` of the first row, or None if
    there is no row (which the comparison layer interprets as 'no matching
    properties' for price dimensions, or 0 for counts).
    """
    async with engine.connect() as conn:
        result = await conn.execute(text(sql))
        keys = list(result.keys())
        rows = result.fetchmany(1)
        data = rows_to_dicts(rows, keys)

    if not data:
        return None
    row = data[0]
    # Prefer the canonical column; fall back to the sole value if aliased oddly.
    if value_column in row:
        return row[value_column]
    return next(iter(row.values()), None)


def _combined_sql(plan: ComparisonPlan) -> str:
    """A human-readable record of both queries for memory/debugging.

    Not executed as one statement — stored only so update_memory has a
    meaningful ``last_sql`` and tests can assert no lat/lon leakage.
    """
    return (
        f"-- {plan.left.city}\n{plan.left.sql}\n"
        f"-- {plan.right.city}\n{plan.right.sql}"
    )


async def build_comparison_query_node(
    state: AgentState,
    config: RunnableConfig,
) -> dict:
    """Build, execute and compare two per-city queries for a COMPARISON intent."""
    user_message = state.get("user_message", "")

    # ── 1. Parse the comparison entities from the CURRENT message only ───
    request = parse_comparison_request(user_message)
    if not request.ok:
        # Could not resolve two cities / a valid dimension — clear message,
        # no execution, no LLM fallback.
        return {
            "assistant_message": request.error,
            "properties": [],
            "result_count": 0,
            "generated_sql": "",
        }

    # ── 2. Build the two deterministic single-table SQLs ─────────────────
    plan = build_comparison_query(request)

    # Defensive: both SQLs must pass the shared validator.  They are built
    # from a fixed template over the properties table, so this should always
    # hold; if it ever fails we surface a clear error instead of executing.
    for side in (plan.left, plan.right):
        ok, err = validate_sql(side.sql)
        if not ok:
            return {
                "assistant_message": (
                    "I wasn't able to build a valid comparison for that request. "
                    "Try comparing two cities by average price, cheapest/highest "
                    "price, or number of matching properties."
                ),
                "properties": [],
                "result_count": 0,
                "generated_sql": _combined_sql(plan),
                "error_message": err,
            }

    engine: AsyncEngine = config["configurable"]["db_engine"]

    # ── 3. Execute both sides independently ──────────────────────────────
    try:
        left_raw = await _execute_scalar(engine, plan.left.sql, plan.value_column)
        right_raw = await _execute_scalar(engine, plan.right.sql, plan.value_column)
    except Exception as exc:  # pragma: no cover - defensive DB error path
        return {
            "assistant_message": (
                "I ran into a problem running that comparison. Please try "
                "rephrasing — for example, 'Compare average prices in Paris "
                "and Berlin'."
            ),
            "properties": [],
            "result_count": 0,
            "generated_sql": _combined_sql(plan),
            "error_message": str(exc),
        }

    # ── 4. Compare and format ─────────────────────────────────────────────
    result = compare_comparison_results(plan, left_raw, right_raw)
    message = format_comparison_message(result)

    # result_count: number of sides that actually produced a value.
    sides_with_value = sum(
        1 for v in (result.left_value, result.right_value) if v is not None
    )

    return {
        "assistant_message": message,
        "properties": [],          # comparisons never return property cards
        "result_count": sides_with_value,
        "generated_sql": _combined_sql(plan),
        "error_message": "",
    }
