"""Node: classify_intent — determines what the user wants (Phase 4.1).

Phase 4.1 changes:
- Uses invoke_json() for structured JSON output: {"intent": "..."}
- Validates against QueryIntent enum
- Robust fallback parsing from raw text
"""

import json
import re

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.prompts import INTENT_SYSTEM, INTENT_USER
from app.agents.free_chat.state import AgentState
from app.domain.chat.schemas import QueryIntent, SessionMemory
from app.infrastructure.llm.base import LLMProvider

_VALID_INTENTS = frozenset(e.value for e in QueryIntent)


async def classify_intent_node(state: AgentState, config: RunnableConfig) -> dict:
    llm: LLMProvider = config["configurable"]["llm"]
    memory = SessionMemory(**(state.get("memory") or {}))

    messages = [
        {"role": "system", "content": INTENT_SYSTEM},
        {
            "role": "user",
            "content": INTENT_USER.format(
                memory_context=memory.to_context_string(),
                user_message=state["user_message"],
            ),
        },
    ]

    intent = await _extract_intent(llm, messages)

    return {
        "intent": intent,
        "clarification_needed": intent == QueryIntent.CLARIFICATION_NEEDED.value,
        "retry_count": state.get("retry_count", 0),
    }


async def _extract_intent(llm: LLMProvider, messages: list[dict]) -> str:
    """Extract intent using JSON parsing with fallback to raw text parsing."""
    # 1. Try invoke_json first
    try:
        result = await llm.invoke_json(messages)
        if isinstance(result, dict) and "intent" in result:
            intent = str(result["intent"]).strip().lower()
            if intent in _VALID_INTENTS:
                return intent
    except Exception:
        pass

    # 2. Fallback: try plain invoke and parse
    try:
        raw = await llm.invoke(messages)
        return _parse_intent_from_text(raw)
    except Exception:
        return QueryIntent.CLARIFICATION_NEEDED.value


def _parse_intent_from_text(raw: str) -> str:
    """Parse intent from raw LLM text output."""
    text = raw.strip()

    # Try JSON parse
    try:
        data = json.loads(text)
        if isinstance(data, dict) and "intent" in data:
            intent = str(data["intent"]).strip().lower()
            if intent in _VALID_INTENTS:
                return intent
    except json.JSONDecodeError:
        pass

    # Try to extract JSON from text
    match = re.search(r'\{[^}]*"intent"\s*:\s*"([^"]+)"[^}]*\}', text)
    if match:
        intent = match.group(1).strip().lower()
        if intent in _VALID_INTENTS:
            return intent

    # Try plain label extraction
    intent = text.lower().strip().rstrip(".")
    if intent in _VALID_INTENTS:
        return intent

    # Search for any valid intent within the response
    for valid in _VALID_INTENTS:
        if valid in intent:
            return valid

    return QueryIntent.CLARIFICATION_NEEDED.value

