"""Node: validate_sql — static safety check (SELECT-only, allowed tables)."""

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.state import AgentState
from app.agents.free_chat.utils import validate_sql


async def validate_sql_node(state: AgentState, config: RunnableConfig) -> dict:
    sql = state.get("generated_sql", "")
    is_valid, error = validate_sql(sql)

    return {
        "sql_valid": is_valid,
        "sql_error": error if not is_valid else "",
        "retry_count": state.get("retry_count", 0) + (0 if is_valid else 1),
    }
