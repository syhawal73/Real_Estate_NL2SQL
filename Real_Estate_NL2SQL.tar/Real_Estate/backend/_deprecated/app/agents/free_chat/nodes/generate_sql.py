"""Node: generate_sql — asks the LLM to produce a SELECT query (Phase 4.1).

Phase 4.1: Uses SearchContext for structured filter context instead of raw SessionMemory.
"""

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.prompts import SCHEMA_CONTEXT, SQL_SYSTEM, SQL_USER
from app.agents.free_chat.state import AgentState
from app.agents.free_chat.utils import clean_sql
from app.domain.chat.schemas import SearchContext
from app.infrastructure.llm.base import LLMProvider


async def generate_sql_node(state: AgentState, config: RunnableConfig) -> dict:
    llm: LLMProvider = config["configurable"]["llm"]
    search_context = SearchContext(**(state.get("search_context") or {}))

    # On retry, include previous error so LLM can fix it
    error_feedback = ""
    if state.get("sql_error"):
        error_feedback = f"Previous SQL failed with: {state['sql_error']}\nPlease fix the query.\n"

    messages = [
        {"role": "system", "content": SQL_SYSTEM.format(schema=SCHEMA_CONTEXT)},
        {
            "role": "user",
            "content": SQL_USER.format(
                search_context=search_context.to_context_string(),
                intent=state.get("intent", "filter_search"),
                error_feedback=error_feedback,
                user_message=state["user_message"],
            ),
        },
    ]

    raw_sql = await llm.invoke(messages)
    sql = clean_sql(raw_sql)

    return {
        "generated_sql": sql,
        "sql_valid": False,   # will be set by validate_sql node
        "sql_error": "",
    }

