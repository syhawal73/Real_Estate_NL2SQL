"""Node: level2_state_manager — Conversation State Management (Level 2)."""

import json
import re

from langchain_core.runnables import RunnableConfig
from app.agents.free_chat.prompts import LEVEL2_SYSTEM, LEVEL2_USER
from app.agents.free_chat.state import AgentState
from app.domain.chat.schemas import SearchContext, ActiveSearchSession
from app.infrastructure.llm.base import LLMProvider

async def level2_state_manager_node(state: AgentState, config: RunnableConfig) -> dict:
    llm: LLMProvider = config["configurable"]["llm"]
    
    current_context = state.get("search_context") or {}
    new_entities = state.get("level1_entities") or {}
    
    # If there are no new entities other than intent, we could skip,
    # but the LLM also handles implicit clear actions based on conversation logic.
    
    messages = [
        {"role": "system", "content": LEVEL2_SYSTEM},
        {
            "role": "user",
            "content": LEVEL2_USER.format(
                current_state=json.dumps(current_context, indent=2),
                extracted_entities=json.dumps(new_entities, indent=2)
            )
        },
    ]
    
    result_text = await llm.invoke(messages)
    
    try:
        text = result_text.strip()
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            text = match.group(0)
        result = json.loads(text)
    except Exception:
        result = current_context
            
    safe_result = {}
    for k, v in result.items():
        if v is None:
            continue
        try:
            SearchContext(**{k: v})
            safe_result[k] = v
        except Exception:
            pass
            
    updated_context = SearchContext(**safe_result)
    
    # Dual-write for ActiveSearchSession
    active = state.get("active_search") or {}
    search_id = active.get("search_id") or None
    active_session = ActiveSearchSession.from_search_context(updated_context, search_id)
    
    return {
        "search_context": updated_context.model_dump(),
        "active_search": active_session.model_dump()
    }
