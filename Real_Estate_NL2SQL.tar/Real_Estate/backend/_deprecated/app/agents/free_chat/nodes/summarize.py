"""Node: summarize_results — natural-language answer (Phase 4.1).

Phase 4.1: Memory update logic moved to dedicated update_memory node.
This node only handles summary generation and property card extraction.

Sprint 3: COUNT and AGGREGATION intents use deterministic numeric summaries
so the answer is always a concrete value, never a SQL fragment or placeholder.
"""

from langchain_core.runnables import RunnableConfig

from app.agents.free_chat.prompts import SUMMARISE_SYSTEM, SUMMARISE_USER
from app.agents.free_chat.state import AgentState
from app.agents.free_chat.utils import truncate_sample
from app.domain.chat.schemas import QueryIntent, SearchContext
from app.infrastructure.llm.base import LLMProvider

# Property fields to extract for the frontend cards
_CARD_FIELDS = {
    "id", "title", "city", "neighbourhood", "intent", "price",
    "bedrooms", "bathrooms", "size_sqm", "property_type", "distance_from_city_km",
}


def _extract_properties(results: list[dict]) -> list[dict]:
    """Filter result rows to only property card fields."""
    out = []
    for r in results:
        if "id" in r:  # looks like a properties row
            out.append({k: r[k] for k in _CARD_FIELDS if k in r})
    return out


def _summarize_count(results: list[dict], search_context: SearchContext) -> str:
    """Return a deterministic human-readable count summary.

    Reads the ``property_count`` column produced by build_count_query.
    Falls back to 0 if the column is absent (should not happen in practice).
    """
    count = 0
    if results:
        row = results[0]
        # build_count_query aliases the column as 'property_count'
        raw = row.get("property_count", row.get("count", 0))
        try:
            count = int(raw) if raw is not None else 0
        except (ValueError, TypeError):
            count = 0

    # Build a context-aware description
    parts: list[str] = []
    if search_context.bedrooms is not None:
        parts.append(f"{search_context.bedrooms}-bedroom")
    if search_context.property_type:
        parts.append(f"{search_context.property_type}s")
    else:
        parts.append("properties")
    if search_context.intent:
        parts.append(f"for {search_context.intent}")
    if search_context.city:
        parts.append(f"in {search_context.city}")
    if search_context.max_price:
        parts.append(f"under {int(search_context.max_price):,}")

    description = " ".join(parts) if parts else "properties"

    if count == 0:
        return f"There are no {description} matching your criteria."
    if count == 1:
        return f"There is 1 {description.rstrip('s')} matching your criteria."
    return f"There are {count:,} {description} matching your criteria."


def _summarize_aggregation(results: list[dict], search_context: SearchContext) -> str:
    """Return a deterministic human-readable aggregation summary.

    Reads whichever aggregate column build_aggregation_query produced
    (avg_price, min_price, or max_price).
    """
    if not results:
        return "No matching properties were found for that query."

    row = results[0]

    # Detect which aggregate was computed and its value
    agg_value = None
    agg_label = "price"
    for col in ("avg_price", "min_price", "max_price"):
        if col in row and row[col] is not None:
            raw = row[col]
            try:
                agg_value = float(raw)
            except (ValueError, TypeError):
                agg_value = None
            if col == "avg_price":
                agg_label = "average price"
            elif col == "min_price":
                agg_label = "lowest price"
            elif col == "max_price":
                agg_label = "highest price"
            break

    if agg_value is None:
        return "No matching properties were found for that query."

    # Currency hint: London → GBP, others → EUR
    city = (search_context.city or "").lower()
    currency = "£" if city == "london" else "€"
    formatted_value = f"{currency}{int(round(agg_value)):,}"

    # Build context description
    parts: list[str] = []
    if search_context.property_type:
        parts.append(f"{search_context.property_type}s")
    else:
        parts.append("properties")
    if search_context.intent:
        parts.append(f"for {search_context.intent}")
    if search_context.city:
        parts.append(f"in {search_context.city}")

    description = " ".join(parts) if parts else "properties"
    return f"The {agg_label} for {description} is {formatted_value}."


async def summarize_node(state: AgentState, config: RunnableConfig) -> dict:
    llm: LLMProvider = config["configurable"]["llm"]
    results = state.get("query_results", [])
    result_count = state.get("result_count", 0)
    intent = state.get("intent", "")

    # ── Sprint 3: deterministic numeric summaries for COUNT / AGGREGATION ─
    if intent == QueryIntent.COUNT.value:
        search_context = SearchContext(**(state.get("search_context") or {}))
        summary = _summarize_count(results, search_context)
        return {
            "assistant_message": summary,
            "properties": [],  # count queries never return property cards
        }

    if intent == QueryIntent.AGGREGATION.value:
        search_context = SearchContext(**(state.get("search_context") or {}))
        summary = _summarize_aggregation(results, search_context)
        return {
            "assistant_message": summary,
            "properties": [],  # aggregation queries never return property cards
        }

    # ── Default path: LLM-generated summary for all other intents ─────────
    sample_str = truncate_sample(results, max_items=3) if results else "none"
    messages = [
        {"role": "system", "content": SUMMARISE_SYSTEM},
        {
            "role": "user",
            "content": SUMMARISE_USER.format(
                user_message=state["user_message"],
                result_count=result_count,
                sample=sample_str,
            ),
        },
    ]
    summary = await llm.invoke(messages)

    # Extract property cards
    properties = _extract_properties(results)

    return {
        "assistant_message": summary.strip(),
        "properties": properties,
    }

