"""Deterministic SQL builders for COUNT, AGGREGATION and COMPARISON queries.

These builders construct SQL directly from structured SearchContext — they
never call the LLM for SQL generation.  This eliminates the class of failures
where the generic SQL generator returns wrong intent filters, partial text, or
uses nonexistent columns (e.g. longitude/latitude on the properties table).

Supported intents
-----------------
COUNT       → build_count_query(...)
             Examples: "How many apartments are for rent in Rome?"
             Returns:  SELECT COUNT(*) AS property_count FROM properties WHERE …

AGGREGATION → build_aggregation_query(...)
             Examples: "What is the average price of houses in Rome?"
                       "What is the cheapest rent available in Paris?"
                       "What is the highest priced apartment in Berlin?"
             Returns:  SELECT AVG(price) / MIN(price) / MAX(price) …
                       with appropriate WHERE clause

COMPARISON  → parse_comparison_request(...) + build_comparison_query(...)
             Examples: "Compare average sale prices in London vs Berlin"
                       "Which city has more rental apartments, Paris or Amsterdam?"
                       "Compare the cheapest apartments in Rome and Paris"
                       "Are houses in Berlin or London more expensive on average?"
             Produces TWO single-table queries (one per city), executed
             independently, whose scalar results are then compared.  The
             only supported dimensions are count / average / min / max price;
             the only supported scope is city vs city, optionally narrowed by
             a shared property_type and/or intent filter.  No other filters
             are invented and no prior-turn context is borrowed.

Constraints applied (where set in SearchContext)
-------------------------------------------------
  city           → WHERE city = '<city>'
  intent         → WHERE intent = 'rent' | 'buy'
  property_type  → WHERE property_type = 'apartment' | 'house'
  bedrooms       → WHERE bedrooms = N
  bathrooms      → WHERE bathrooms = N
  max_price      → WHERE price <= N   (COUNT only; AGGREGATION uses it as an
                   optional upper bound when explicitly requested)

Columns used are ONLY from the properties table.
city_centers is NEVER referenced — no latitude/longitude joins.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from app.domain.chat.schemas import SearchContext


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_where_clause(
    city: str | None,
    intent: str | None,
    property_type: str | None,
    bedrooms: int | None,
    bathrooms: int | None,
    max_price: float | None,
) -> tuple[str, list]:
    """Construct a parameterised WHERE clause from filter values.

    Returns ``(where_sql, params)`` where ``where_sql`` is the full
    ``WHERE …`` string with ``%s`` placeholders (empty string if no
    filters) and ``params`` is the ordered list of bind values.

    NOTE: The caller can choose to embed the values directly (since all
    values come from our own SearchContext, not user text), but we use
    placeholders here for correctness.  The execute_query node inlines
    them via safe string formatting — see _inline_params below.
    """
    conditions: list[str] = []
    params: list = []

    if city:
        conditions.append("city = %s")
        params.append(city)

    if intent in ("rent", "buy"):
        conditions.append("intent = %s")
        params.append(intent)

    if property_type in ("apartment", "house"):
        conditions.append("property_type = %s")
        params.append(property_type)

    if bedrooms is not None:
        conditions.append("bedrooms = %s")
        params.append(bedrooms)

    if bathrooms is not None:
        conditions.append("bathrooms = %s")
        params.append(bathrooms)

    if max_price is not None:
        conditions.append("price <= %s")
        params.append(int(max_price))

    if not conditions:
        return "", params

    where = "WHERE " + " AND ".join(conditions)
    return where, params


def _inline_params(sql_template: str, params: list) -> str:
    """Replace ``%s`` placeholders with safely-quoted literal values.

    Values come exclusively from our own SearchContext schema (strings
    are city/intent/property_type, integers are bedrooms/price).  We
    quote strings with single quotes and escape embedded single quotes.
    Numbers are embedded as plain integers.
    """
    result = sql_template
    for p in params:
        if isinstance(p, str):
            escaped = p.replace("'", "''")
            replacement = f"'{escaped}'"
        else:
            replacement = str(int(p))
        result = result.replace("%s", replacement, 1)
    return result


# ---------------------------------------------------------------------------
# Aggregation function detection
# ---------------------------------------------------------------------------

# Maps keywords that appear in user messages to SQL aggregate functions.
# Checked in priority order — first match wins.
_AGG_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\baverage\b|\bavg\b|\bmean\b", re.IGNORECASE), "AVG"),
    (re.compile(r"\bcheapest\b|\blowest\b|\bminimum\b|\bmin\b|\bcheap\b", re.IGNORECASE), "MIN"),
    (re.compile(r"\bmost\s+expensive\b|\bhighest\b|\bmaximum\b|\bmax\b|\bpriciest\b", re.IGNORECASE), "MAX"),
]

_DEFAULT_AGG_FUNC = "AVG"


def _detect_agg_function(user_message: str) -> str:
    """Return the SQL aggregate function implied by the user message."""
    for pattern, func in _AGG_PATTERNS:
        if pattern.search(user_message):
            return func
    return _DEFAULT_AGG_FUNC


# ---------------------------------------------------------------------------
# Public builders
# ---------------------------------------------------------------------------

def build_count_query(
    search_context: SearchContext,
    user_message: str = "",
) -> str:
    """Build a deterministic COUNT(*) query from structured search context.

    Parameters
    ----------
    search_context:
        The current SearchContext holding all active filters.
    user_message:
        The raw user message (unused for SQL construction; accepted for
        API symmetry and potential future use).

    Returns
    -------
    str
        A complete, ready-to-execute SQL string such as::

            SELECT COUNT(*) AS property_count
            FROM properties
            WHERE city = 'Rome' AND intent = 'rent' AND property_type = 'apartment'

        If no filters are set, the WHERE clause is omitted.
    """
    where_template, params = _build_where_clause(
        city=search_context.city,
        intent=search_context.intent,
        property_type=search_context.property_type,
        bedrooms=search_context.bedrooms,
        bathrooms=search_context.bathrooms,
        max_price=search_context.max_price,
    )

    where_sql = _inline_params(where_template, params)

    parts = ["SELECT COUNT(*) AS property_count", "FROM properties"]
    if where_sql:
        parts.append(where_sql)

    return "\n".join(parts)


def build_aggregation_query(
    search_context: SearchContext,
    user_message: str = "",
) -> str:
    """Build a deterministic price aggregation query from structured context.

    The aggregate function (AVG / MIN / MAX) is inferred from keywords in
    ``user_message``; defaults to AVG if no keyword matches.

    Parameters
    ----------
    search_context:
        The current SearchContext holding all active filters.
    user_message:
        The raw user message used to detect the aggregate function
        (average / cheapest / highest etc.).

    Returns
    -------
    str
        A complete, ready-to-execute SQL string such as::

            SELECT AVG(price) AS avg_price
            FROM properties
            WHERE city = 'Rome' AND property_type = 'house'

        The column alias reflects the chosen function
        (``avg_price``, ``min_price``, ``max_price``).
    """
    agg_func = _detect_agg_function(user_message)
    return _build_agg_sql(search_context, agg_func)


def _build_agg_sql(search_context: SearchContext, agg_func: str) -> str:
    """Build a price aggregation query for an explicit aggregate function.

    Shared by :func:`build_aggregation_query` (which infers the function
    from the user message) and :func:`build_comparison_query` (which already
    knows the function from the resolved comparison dimension).

    ``agg_func`` must be one of ``"AVG"``, ``"MIN"``, ``"MAX"``.
    The column alias mirrors the function (``avg_price`` / ``min_price`` /
    ``max_price``).  ``max_price`` from the context is never applied as a
    filter — the caller wants the computed value across all matching rows.
    """
    alias = f"{agg_func.lower()}_price"

    # For aggregation queries we do NOT apply max_price as a filter by
    # default — the user is asking for the computed value across all
    # matching properties, not filtering by their budget.
    where_template, params = _build_where_clause(
        city=search_context.city,
        intent=search_context.intent,
        property_type=search_context.property_type,
        bedrooms=search_context.bedrooms,
        bathrooms=search_context.bathrooms,
        max_price=None,  # intentionally excluded for aggregation
    )

    where_sql = _inline_params(where_template, params)

    parts = [f"SELECT {agg_func}(price) AS {alias}", "FROM properties"]
    if where_sql:
        parts.append(where_sql)

    return "\n".join(parts)


# ===========================================================================
# COMPARISON builder (city vs city)
# ===========================================================================
#
# A comparison query is fundamentally two single-table queries — one per
# city — whose scalar results are compared.  We build both SQL strings
# deterministically (reusing the COUNT / AGGREGATION builders above) and
# leave execution to the comparison node.  Nothing here calls the LLM and
# no prior-turn context is consulted: every entity is parsed from the
# current user message only, so a stale city can never leak in.


# ── Supported comparison dimensions ────────────────────────────────────────
# Internal canonical dimension identifiers.  Each maps to a result column.
DIM_COUNT = "count"
DIM_AVG = "avg_price"
DIM_MIN = "min_price"
DIM_MAX = "max_price"

_VALID_DIMENSIONS = frozenset({DIM_COUNT, DIM_AVG, DIM_MIN, DIM_MAX})

# Result column produced by each dimension's SQL.
_DIM_VALUE_COLUMN = {
    DIM_COUNT: "property_count",
    DIM_AVG: "avg_price",
    DIM_MIN: "min_price",
    DIM_MAX: "max_price",
}

# Aggregate SQL function for the price dimensions.
_DIM_AGG_FUNC = {
    DIM_AVG: "AVG",
    DIM_MIN: "MIN",
    DIM_MAX: "MAX",
}

# Whether, for a given dimension, the *larger* numeric value is the "winner".
#   count       → more matches wins        (larger)
#   avg / max   → higher price is "more"   (larger)
#   min         → cheapest wins            (smaller)
_DIM_LARGER_WINS = {
    DIM_COUNT: True,
    DIM_AVG: True,
    DIM_MIN: False,
    DIM_MAX: True,
}

# Cities the system supports (mirrors extract_constraints._CITY_PROPER).
_COMPARISON_CITIES = {
    "london": "London",
    "paris": "Paris",
    "berlin": "Berlin",
    "amsterdam": "Amsterdam",
    "rome": "Rome",
}


# ── Entity parsing (deterministic, current message only) ────────────────────

def _extract_cities_in_order(message: str) -> list[str]:
    """Return distinct supported cities in their order of appearance.

    Uses word-boundary matching so 'Rome' inside another word is not
    matched.  Duplicates are collapsed, preserving first-seen order.
    """
    found: list[str] = []
    seen: set[str] = set()
    for match in re.finditer(r"[a-zA-Z]+", message):
        token = match.group(0).lower()
        if token in _COMPARISON_CITIES and token not in seen:
            seen.add(token)
            found.append(_COMPARISON_CITIES[token])
    return found


def _detect_comparison_dimension(message: str) -> str:
    """Resolve the comparison dimension from the user message.

    Resolution order is significant:
      1. Superlatives  ('cheapest' → MIN, 'most expensive' → MAX)
      2. Explicit average keywords ('average', 'avg', 'mean', 'on average')
      3. Price comparatives without a superlative ('more/less expensive',
         'cheaper', 'pricier')  → AVG (a fair like-for-like comparison)
      4. Count signals ('how many', 'number of', 'more', 'most', 'count')
      5. Default → AVG
    """
    m = message.lower()

    if re.search(r"\b(cheapest|lowest\s+priced?|least\s+expensive)\b", m):
        return DIM_MIN
    if re.search(r"\b(most\s+expensive|highest\s+priced?|priciest|dearest)\b", m):
        return DIM_MAX
    if re.search(r"\b(average|avg|mean)\b", m) or "on average" in m:
        return DIM_AVG
    if re.search(r"\b(more|less)\s+expensive\b", m) or re.search(r"\b(cheaper|pricier)\b", m):
        return DIM_AVG
    if re.search(r"\b(how\s+many|number\s+of|count|more|most|fewer|fewest)\b", m):
        return DIM_COUNT
    return DIM_AVG


def _detect_shared_intent(message: str) -> str | None:
    """Detect a shared rent/buy intent applied to both sides of a comparison."""
    m = message.lower()
    if re.search(r"\b(rent|rental|rentals|renting|to\s+rent|lease|letting)\b", m):
        return "rent"
    if re.search(r"\b(sale|sales|buy|buying|purchase|purchasing|to\s+buy|for\s+sale)\b", m):
        return "buy"
    return None


def _detect_shared_property_type(message: str) -> str | None:
    """Detect a shared apartment/house filter applied to both sides."""
    m = message.lower()
    if re.search(r"\b(house|houses|home|homes|villa|villas)\b", m):
        return "house"
    if re.search(r"\b(apartment|apartments|flat|flats|studio|studios|condo|condos)\b", m):
        return "apartment"
    return None


@dataclass
class ComparisonRequest:
    """Parsed, validated description of a city-vs-city comparison.

    ``ok`` is False when the message could not be resolved into a valid
    two-city comparison (e.g. fewer than two supported cities named).  In
    that case ``error`` carries a user-facing explanation and the entity
    fields are unset.
    """

    ok: bool
    dimension: str | None = None
    left_city: str | None = None
    right_city: str | None = None
    property_type: str | None = None
    intent: str | None = None
    error: str | None = None


def parse_comparison_request(user_message: str) -> ComparisonRequest:
    """Parse a comparison request from the current user message only.

    Deliberately ignores any prior SearchContext so a city from an earlier
    turn can never leak into a fresh comparison.  Requires exactly two
    distinct supported cities to be named; anything else yields a clear,
    non-executing error result.
    """
    if not user_message or not user_message.strip():
        return ComparisonRequest(
            ok=False,
            error="Please name the two cities you'd like to compare.",
        )

    cities = _extract_cities_in_order(user_message)

    if len(cities) < 2:
        named = cities[0] if cities else None
        if named:
            other = "another city"
            return ComparisonRequest(
                ok=False,
                error=(
                    f"I can compare {named} with another city, but I only found "
                    f"one city in your request. Which two cities should I compare? "
                    f"I support London, Paris, Berlin, Amsterdam, and Rome."
                ),
            )
        return ComparisonRequest(
            ok=False,
            error=(
                "Which two cities would you like me to compare? "
                "I support London, Paris, Berlin, Amsterdam, and Rome."
            ),
        )

    # City vs city: take the first two distinct cities mentioned.
    left_city, right_city = cities[0], cities[1]

    dimension = _detect_comparison_dimension(user_message)
    property_type = _detect_shared_property_type(user_message)
    intent = _detect_shared_intent(user_message)

    return ComparisonRequest(
        ok=True,
        dimension=dimension,
        left_city=left_city,
        right_city=right_city,
        property_type=property_type,
        intent=intent,
    )


# ── SQL plan construction ───────────────────────────────────────────────────

@dataclass
class ComparisonSide:
    """One side of a comparison: a city, its SQL, and its (post-exec) value."""

    city: str
    sql: str
    value: float | None = None
    has_result: bool = False


@dataclass
class ComparisonPlan:
    """A fully-built, ready-to-execute comparison.

    Holds the two per-city SQL strings plus the metadata needed to compare
    and describe their scalar results.  Built entirely from a
    ``ComparisonRequest`` — no LLM, no DB, no prior context.
    """

    dimension: str
    value_column: str
    larger_wins: bool
    property_type: str | None
    intent: str | None
    left: ComparisonSide
    right: ComparisonSide


def _build_side_sql(
    city: str,
    dimension: str,
    property_type: str | None,
    intent: str | None,
) -> str:
    """Build the single-table SQL for one side of the comparison."""
    ctx = SearchContext(
        city=city,
        intent=intent,
        property_type=property_type,
    )
    if dimension == DIM_COUNT:
        return build_count_query(ctx)
    agg_func = _DIM_AGG_FUNC[dimension]
    return _build_agg_sql(ctx, agg_func)


def build_comparison_query(request: ComparisonRequest) -> ComparisonPlan:
    """Build the two-query plan for a parsed comparison request.

    Parameters
    ----------
    request:
        A successful :class:`ComparisonRequest` (``request.ok is True``).

    Raises
    ------
    ValueError
        If the request is not valid (caller should check ``request.ok``
        first and surface ``request.error`` instead of building).
    """
    if not request.ok:
        raise ValueError(
            "build_comparison_query called with an invalid ComparisonRequest; "
            "check request.ok and surface request.error instead."
        )
    if request.dimension not in _VALID_DIMENSIONS:
        raise ValueError(f"Unsupported comparison dimension: {request.dimension!r}")

    left_sql = _build_side_sql(
        request.left_city, request.dimension, request.property_type, request.intent
    )
    right_sql = _build_side_sql(
        request.right_city, request.dimension, request.property_type, request.intent
    )

    return ComparisonPlan(
        dimension=request.dimension,
        value_column=_DIM_VALUE_COLUMN[request.dimension],
        larger_wins=_DIM_LARGER_WINS[request.dimension],
        property_type=request.property_type,
        intent=request.intent,
        left=ComparisonSide(city=request.left_city, sql=left_sql),
        right=ComparisonSide(city=request.right_city, sql=right_sql),
    )


# ── Result comparison + formatting ──────────────────────────────────────────

# Comparison outcome status codes.
CMP_OK = "ok"                       # both sides have values; a winner or tie
CMP_TIE = "tie"                     # both sides have equal values
CMP_NO_RESULTS_LEFT = "no_left"     # left side has no matching properties
CMP_NO_RESULTS_RIGHT = "no_right"   # right side has no matching properties
CMP_NO_RESULTS_BOTH = "no_both"     # neither side has matching properties


@dataclass
class ComparisonResult:
    """The compared outcome of a two-city comparison."""

    dimension: str
    status: str
    left_city: str
    right_city: str
    left_value: float | None
    right_value: float | None
    winner: str | None  # city name, or None for ties / no-result cases
    property_type: str | None = None
    intent: str | None = None


def _coerce_value(raw, dimension: str) -> float | None:
    """Coerce a raw DB scalar into a number, or None if absent/NULL.

    For COUNT a NULL/absent value is treated as 0 (a real, comparable count).
    For AVG/MIN/MAX a NULL means there were no matching rows → None.
    """
    if raw is None:
        return 0.0 if dimension == DIM_COUNT else None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return 0.0 if dimension == DIM_COUNT else None


def compare_comparison_results(
    plan: ComparisonPlan,
    left_raw,
    right_raw,
) -> ComparisonResult:
    """Compare the two scalar results and determine the winner / tie / no-result.

    ``left_raw`` / ``right_raw`` are the raw scalar values pulled from each
    side's result row (already extracted from ``plan.value_column``).
    """
    left_val = _coerce_value(left_raw, plan.dimension)
    right_val = _coerce_value(right_raw, plan.dimension)

    left_missing = left_val is None
    right_missing = right_val is None

    base = dict(
        dimension=plan.dimension,
        left_city=plan.left.city,
        right_city=plan.right.city,
        left_value=left_val,
        right_value=right_val,
        property_type=plan.property_type,
        intent=plan.intent,
    )

    # No-result handling (only relevant for price dimensions, where NULL
    # means "no matching properties"; COUNT coerces to 0 instead).
    if left_missing and right_missing:
        return ComparisonResult(status=CMP_NO_RESULTS_BOTH, winner=None, **base)
    if left_missing:
        return ComparisonResult(status=CMP_NO_RESULTS_LEFT, winner=plan.right.city, **base)
    if right_missing:
        return ComparisonResult(status=CMP_NO_RESULTS_RIGHT, winner=plan.left.city, **base)

    # Both sides have a value — tie or winner.
    if left_val == right_val:
        return ComparisonResult(status=CMP_TIE, winner=None, **base)

    if plan.larger_wins:
        winner = plan.left.city if left_val > right_val else plan.right.city
    else:
        winner = plan.left.city if left_val < right_val else plan.right.city

    return ComparisonResult(status=CMP_OK, winner=winner, **base)


# Human-readable phrase per dimension.
_DIM_NOUN = {
    DIM_COUNT: "matching properties",
    DIM_AVG: "average price",
    DIM_MIN: "cheapest price",
    DIM_MAX: "highest price",
}


def _currency_symbol(city: str | None) -> str:
    """London prices are GBP; all other supported cities use EUR."""
    return "£" if (city or "").lower() == "london" else "€"


def _format_price(value: float, city: str) -> str:
    return f"{_currency_symbol(city)}{int(round(value)):,}"


def _scope_phrase(result: ComparisonResult) -> str:
    """Describe the shared scope, e.g. 'rental apartments' or 'houses for sale'."""
    parts: list[str] = []
    if result.property_type:
        parts.append(f"{result.property_type}s")
    else:
        parts.append("properties")
    if result.intent == "rent":
        parts.insert(0, "rental")
        # 'rental properties' / 'rental apartments'
        return " ".join(parts)
    if result.intent == "buy":
        parts.append("for sale")
    return " ".join(parts)


def format_comparison_message(result: ComparisonResult) -> str:
    """Render a deterministic, numeric, human-readable comparison answer.

    Never contains SQL.  Always reports both sides' values where available
    and names the winner (or states a tie / no-results clearly).
    """
    scope = _scope_phrase(result)
    lc, rc = result.left_city, result.right_city

    # ── COUNT dimension ──────────────────────────────────────────────
    if result.dimension == DIM_COUNT:
        lv = int(result.left_value or 0)
        rv = int(result.right_value or 0)

        if lv == 0 and rv == 0:
            return (
                f"Neither {lc} nor {rc} has any {scope} matching your criteria "
                f"({lc}: 0, {rc}: 0)."
            )
        if result.status == CMP_TIE:
            return (
                f"It's a tie: both {lc} and {rc} have {lv:,} {scope} "
                f"({lc}: {lv:,}, {rc}: {rv:,})."
            )
        winner = result.winner
        loser = rc if winner == lc else lc
        win_v = lv if winner == lc else rv
        lose_v = rv if winner == lc else lv
        if lose_v == 0:
            return (
                f"{winner} has more {scope}: {win_v:,}, while {loser} has none "
                f"({lc}: {lv:,}, {rc}: {rv:,})."
            )
        return (
            f"{winner} has more {scope} ({win_v:,}) than {loser} ({lose_v:,}) "
            f"({lc}: {lv:,}, {rc}: {rv:,})."
        )

    # ── Price dimensions (AVG / MIN / MAX) ───────────────────────────
    noun = _DIM_NOUN[result.dimension]

    if result.status == CMP_NO_RESULTS_BOTH:
        return (
            f"I couldn't find any {scope} in {lc} or {rc}, so there's no "
            f"{noun} to compare."
        )
    if result.status == CMP_NO_RESULTS_LEFT:
        rv = _format_price(result.right_value, rc)
        return (
            f"I couldn't find any {scope} in {lc}, so I can't compare. "
            f"For {rc}, the {noun} is {rv}."
        )
    if result.status == CMP_NO_RESULTS_RIGHT:
        lv = _format_price(result.left_value, lc)
        return (
            f"I couldn't find any {scope} in {rc}, so I can't compare. "
            f"For {lc}, the {noun} is {lv}."
        )

    lv_str = _format_price(result.left_value, lc)
    rv_str = _format_price(result.right_value, rc)

    if result.status == CMP_TIE:
        return (
            f"It's a tie: the {noun} for {scope} is the same in both "
            f"{lc} ({lv_str}) and {rc} ({rv_str})."
        )

    winner = result.winner
    win_str = lv_str if winner == lc else rv_str
    lose_city = rc if winner == lc else lc
    lose_str = rv_str if winner == lc else lv_str

    if result.dimension == DIM_MIN:
        # Cheapest wins → lower value.
        return (
            f"{winner} has the cheaper {scope}: {win_str}, "
            f"versus {lose_str} in {lose_city} "
            f"({lc}: {lv_str}, {rc}: {rv_str})."
        )

    # AVG or MAX → higher value is "more expensive".
    descriptor = "average price" if result.dimension == DIM_AVG else "highest price"
    return (
        f"{winner} has the higher {descriptor} for {scope}: {win_str}, "
        f"versus {lose_str} in {lose_city} "
        f"({lc}: {lv_str}, {rc}: {rv_str})."
    )


# ===========================================================================
# RANKING builder (top-N cheapest / largest / closest etc.)
# ===========================================================================
#
# A ranking query returns individual property rows ordered by a single
# dimension (price, size_sqm, or distance_from_city_km) with an optional
# limit.  Like comparison, every entity is parsed from the CURRENT user
# message only — no prior-turn SearchContext is consulted — so stale
# filters can never leak in.

# ── Ranking dimension constants ────────────────────────────────────────────
RANK_PRICE = "price"
RANK_SIZE = "size_sqm"
RANK_DISTANCE = "distance_from_city_km"

_VALID_RANK_DIMENSIONS = frozenset({RANK_PRICE, RANK_SIZE, RANK_DISTANCE})

_DEFAULT_RANKING_LIMIT = 5

# Cities the system supports (reuses the same set as comparison).
_RANKING_CITIES = {
    "london": "London",
    "paris": "Paris",
    "berlin": "Berlin",
    "amsterdam": "Amsterdam",
    "rome": "Rome",
}


# ── Entity parsing (deterministic, current message only) ────────────────────

def _detect_rank_dimension(message: str) -> tuple[str, str]:
    """Detect the ranking dimension and sort order from the user message.

    Returns ``(rank_by, rank_order)`` where rank_by is one of the
    ``RANK_*`` constants and rank_order is ``"asc"`` or ``"desc"``.

    Resolution order:
      1. Price superlatives: cheapest/lowest price → price ASC;
         most expensive/highest price → price DESC
      2. Size superlatives: largest/biggest → size_sqm DESC;
         smallest → size_sqm ASC
      3. Distance superlatives: closest/nearest → distance ASC
      4. Default → price ASC (cheapest)
    """
    m = message.lower()

    # Price-based
    if re.search(r"\b(cheapest|lowest\s+price|least\s+expensive|cheap)\b", m):
        return RANK_PRICE, "asc"
    if re.search(r"\b(most\s+expensive|highest\s+price|priciest|dearest|expensive)\b", m):
        return RANK_PRICE, "desc"

    # Size-based
    if re.search(r"\b(largest|biggest|most\s+spacious)\b", m):
        return RANK_SIZE, "desc"
    if re.search(r"\b(smallest|tiniest)\b", m):
        return RANK_SIZE, "asc"

    # Distance-based
    if re.search(r"\b(closest|nearest)\b", m):
        return RANK_DISTANCE, "asc"
    if re.search(r"\b(farthest|furthest|most\s+remote)\b", m):
        return RANK_DISTANCE, "desc"

    # Default: cheapest
    return RANK_PRICE, "asc"


def _detect_ranking_limit(message: str) -> int:
    """Extract an explicit top-N limit from the user message.

    Patterns matched:
      - "top 5", "first 3"
      - "5 cheapest", "3 largest"
      - "show me 10"

    Returns ``_DEFAULT_RANKING_LIMIT`` if no explicit limit is found.
    """
    m = message.lower()

    # "top N" / "first N" / "show N" / "show me N"
    match = re.search(r"\b(?:top|first|show\s+(?:me\s+)?)\s*(\d+)\b", m)
    if match:
        return int(match.group(1))

    # "N cheapest" / "N largest" / "N closest" / "N most expensive" etc.
    match = re.search(
        r"\b(\d+)\s+(?:cheapest|most\s+expensive|largest|biggest|smallest|"
        r"closest|nearest|priciest|houses?|apartments?|properties)",
        m,
    )
    if match:
        return int(match.group(1))

    return _DEFAULT_RANKING_LIMIT


def _detect_ranking_city(message: str) -> str | None:
    """Extract a single city from the user message for ranking."""
    m = message.lower()
    for city_lower, city_proper in _RANKING_CITIES.items():
        if re.search(rf"\b{re.escape(city_lower)}\b", m):
            return city_proper
    return None


def _detect_ranking_intent(message: str) -> str | None:
    """Detect rent/buy intent from the user message for ranking."""
    m = message.lower()
    if re.search(r"\b(for\s+sale|buy|buying|purchase|purchasing|to\s+buy|sale|sales)\b", m):
        return "buy"
    if re.search(r"\b(rent|rental|rentals|renting|to\s+rent|lease|letting|for\s+rent)\b", m):
        return "rent"
    return None


def _detect_ranking_property_type(message: str) -> str | None:
    """Detect apartment/house filter from the user message for ranking."""
    m = message.lower()
    if re.search(r"\b(house|houses|home|homes|villa|villas)\b", m):
        return "house"
    if re.search(r"\b(apartment|apartments|flat|flats|studio|studios|condo|condos)\b", m):
        return "apartment"
    return None


def _detect_ranking_bedrooms(message: str) -> int | None:
    """Extract bedrooms count from the user message."""
    match = re.search(r"(\d+)\s*[-\s]?(?:bed(?:room)?s?|br)\b", message, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return None


def _detect_ranking_max_price(message: str) -> float | None:
    """Extract a budget/max price from the user message."""
    match = re.search(
        r"(?:under|below|max|less\s+than|up\s+to|budget)\s*"
        r"[£€$]?\s*(\d+)\s*k?\b",
        message, re.IGNORECASE,
    )
    if match:
        price = int(match.group(1))
        if "k" in message[match.start():match.end() + 2].lower() or price < 1000:
            price *= 1000
        return float(price)
    return None


def _detect_ranking_radius(message: str) -> float | None:
    """Extract a radius constraint (km) from the user message."""
    match = re.search(r"(\d+(?:\.\d+)?)\s*km\b", message, re.IGNORECASE)
    if match:
        return float(match.group(1))
    return None


@dataclass
class RankingRequest:
    """Parsed, validated description of a ranking query.

    ``ok`` is False when the message could not be resolved into a valid
    ranking request.  In that case ``error`` carries a user-facing
    explanation and the entity fields are unset.
    """

    ok: bool
    rank_by: str | None = None       # RANK_PRICE | RANK_SIZE | RANK_DISTANCE
    rank_order: str | None = None    # "asc" | "desc"
    limit: int | None = None
    city: str | None = None
    intent: str | None = None        # "rent" | "buy"
    property_type: str | None = None  # "apartment" | "house"
    bedrooms: int | None = None
    max_price: float | None = None
    radius_km: float | None = None
    error: str | None = None


def parse_ranking_request(user_message: str) -> RankingRequest:
    """Parse a ranking request from the current user message only.

    Deliberately ignores any prior SearchContext so a city or filter from
    an earlier turn can never leak into a fresh ranking request.
    """
    if not user_message or not user_message.strip():
        return RankingRequest(
            ok=False,
            error="Please tell me what you'd like to rank — for example, "
                  "'Show the 5 cheapest apartments in Berlin'.",
        )

    rank_by, rank_order = _detect_rank_dimension(user_message)
    limit = _detect_ranking_limit(user_message)
    city = _detect_ranking_city(user_message)
    intent = _detect_ranking_intent(user_message)
    property_type = _detect_ranking_property_type(user_message)
    bedrooms = _detect_ranking_bedrooms(user_message)
    max_price = _detect_ranking_max_price(user_message)
    radius_km = _detect_ranking_radius(user_message)

    return RankingRequest(
        ok=True,
        rank_by=rank_by,
        rank_order=rank_order,
        limit=limit,
        city=city,
        intent=intent,
        property_type=property_type,
        bedrooms=bedrooms,
        max_price=max_price,
        radius_km=radius_km,
    )


# ── SQL construction ───────────────────────────────────────────────────────

# All property-card columns returned by ranking queries.
_RANKING_SELECT_COLUMNS = (
    "id, title, city, neighbourhood, intent, price, bedrooms, bathrooms, "
    "size_sqm, property_type, distance_from_city_km"
)


def build_ranking_query(request: RankingRequest) -> str:
    """Build a deterministic ranking SELECT from a parsed RankingRequest.

    Parameters
    ----------
    request:
        A successful :class:`RankingRequest` (``request.ok is True``).

    Returns
    -------
    str
        A complete, ready-to-execute SQL string such as::

            SELECT id, title, city, ...
            FROM properties
            WHERE city = 'Berlin' AND property_type = 'apartment'
            ORDER BY price ASC
            LIMIT 5
    """
    if not request.ok:
        raise ValueError(
            "build_ranking_query called with an invalid RankingRequest; "
            "check request.ok and surface request.error instead."
        )

    # Build WHERE clause from filters
    where_template, params = _build_where_clause(
        city=request.city,
        intent=request.intent,
        property_type=request.property_type,
        bedrooms=request.bedrooms,
        bathrooms=None,
        max_price=request.max_price,
    )

    # Radius filter (additional WHERE condition)
    if request.radius_km is not None:
        radius_condition = "distance_from_city_km <= %s"
        if where_template:
            where_template += f" AND {radius_condition}"
        else:
            where_template = f"WHERE {radius_condition}"
        params.append(request.radius_km)

    where_sql = _inline_params(where_template, params)

    parts = [
        f"SELECT {_RANKING_SELECT_COLUMNS}",
        "FROM properties",
    ]
    if where_sql:
        parts.append(where_sql)

    parts.append(f"ORDER BY {request.rank_by} {request.rank_order.upper()}")
    parts.append(f"LIMIT {request.limit}")

    return "\n".join(parts)


# ── Result formatting ──────────────────────────────────────────────────────

# Human-readable dimension names for the summary.
_RANK_DIM_NOUN = {
    RANK_PRICE: "price",
    RANK_SIZE: "size",
    RANK_DISTANCE: "distance from city centre",
}

# Adjective describing the ranking direction.
_RANK_DIRECTION_ADJ = {
    (RANK_PRICE, "asc"): "cheapest",
    (RANK_PRICE, "desc"): "most expensive",
    (RANK_SIZE, "desc"): "largest",
    (RANK_SIZE, "asc"): "smallest",
    (RANK_DISTANCE, "asc"): "closest",
    (RANK_DISTANCE, "desc"): "farthest",
}


def format_ranking_message(
    request: RankingRequest,
    results: list[dict],
) -> str:
    """Render a deterministic, human-readable ranking summary.

    Never contains SQL.  Reports the number of results found and
    describes the ranking criteria applied.
    """
    count = len(results)
    adj = _RANK_DIRECTION_ADJ.get(
        (request.rank_by, request.rank_order), "top"
    )

    # Build scope description
    scope_parts: list[str] = []
    if request.property_type:
        scope_parts.append(f"{request.property_type}s")
    else:
        scope_parts.append("properties")
    if request.intent == "rent":
        scope_parts.insert(0, "rental")
    elif request.intent == "buy":
        scope_parts.append("for sale")
    if request.city:
        scope_parts.append(f"in {request.city}")
    if request.radius_km is not None:
        scope_parts.append(f"within {request.radius_km}km")

    scope = " ".join(scope_parts)

    if count == 0:
        return f"I couldn't find any {scope} matching your criteria."

    limit_desc = f"top {request.limit}" if request.limit else "top"

    if count < request.limit:
        return (
            f"Here are all {count} {scope}, ranked by {adj} first. "
            f"(Only {count} matched your criteria.)"
        )

    return f"Here are the {limit_desc} {adj} {scope}, ranked by {_RANK_DIM_NOUN.get(request.rank_by, request.rank_by)}."
