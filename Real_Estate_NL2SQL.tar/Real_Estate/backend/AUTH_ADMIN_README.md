# Authentication & Admin

## Local bootstrap

The API creates the single POC admin account on startup from:

- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

Change these values in your local `.env` before using the project.

## Authentication

Browser authentication uses a secure, HTTP-only cookie with a 14-day opaque session stored server-side in PostgreSQL. Registration requires email verification. If SMTP is not configured, verification/reset links are logged by the backend so the POC remains usable locally.

## Admin

The admin panel is available at `/admin` and is protected both by the React route guard and FastAPI role checks. This POC intentionally enforces exactly one `ADMIN` account.

The admin panel covers:

- dashboard statistics
- property CRUD
- property ownership metadata (agent/user/agency)
- user management
- conversation inspection
- audit logs
- runtime LLM provider configuration

## Database

New auth/admin tables are registered through SQLAlchemy startup `create_all`. For an existing database, `db_seed/migrations/001_auth_admin.sql` is also provided as an explicit migration script.
